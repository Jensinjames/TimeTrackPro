import { create } from 'zustand';
import { supabase } from './supabase';
import { ensureProfileExists } from './ensureProfileExists';
import type { CategoryDefinition, MetricDataPoint, CategoryPreference, CategoryWithPreferences } from './types';

interface CategoryStore {
  categories: CategoryWithPreferences[];
  isLoading: boolean;
  error: string | null;
  
  fetchCategories: () => Promise<void>;
  addCategory: (category: Partial<CategoryDefinition>) => Promise<void>;
  updateCategory: (id: string, updates: Partial<CategoryDefinition>) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;
  
  addMetric: (metric: Omit<MetricDataPoint, 'id' | 'created_at' | 'score'>) => Promise<void>;
  updateMetric: (id: string, updates: Partial<MetricDataPoint>) => Promise<void>;
  deleteMetric: (id: string) => Promise<void>;
  
  updatePreferences: (categoryId: string, preferences: Partial<CategoryPreference>) => Promise<void>;
}

export const useCategoryStore = create<CategoryStore>((set, get) => ({
  categories: [],
  isLoading: false,
  error: null,

  fetchCategories: async () => {
    set({ isLoading: true });
    try {
      const { data: categories, error: categoriesError } = await supabase
        .from('category_definitions')
        .select(`
          *,
          preferences:category_preferences(*),
          metrics:metric_data_points(*)
        `)
        .order('display_order', { ascending: true });

      if (categoriesError) throw categoriesError;

      const categoryMap = new Map<string, CategoryWithPreferences>();
      const rootCategories: CategoryWithPreferences[] = [];

      categories?.forEach(category => {
        category.children = [];
        categoryMap.set(category.id, category);
      });

      categories?.forEach(category => {
        if (category.parent_id) {
          const parent = categoryMap.get(category.parent_id);
          if (parent) {
            parent.children?.push(category);
          }
        } else {
          rootCategories.push(category);
        }
      });

      set({ categories: rootCategories, error: null });
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ isLoading: false });
    }
  },

  addCategory: async (category) => {
    try {
      const { error } = await supabase
        .from('category_definitions')
        .insert([category]);

      if (error) throw error;
      get().fetchCategories();
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },

  updateCategory: async (id, updates) => {
    try {
      const { error } = await supabase
        .from('category_definitions')
        .update(updates)
        .eq('id', id);

      if (error) throw error;
      get().fetchCategories();
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },

  deleteCategory: async (id) => {
    try {
      const { error } = await supabase
        .from('category_definitions')
        .delete()
        .eq('id', id);

      if (error) throw error;
      get().fetchCategories();
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },

  addMetric: async (metric) => {
    try {
      // Get current user
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError) throw userError;
      if (!user) throw new Error('Not authenticated');

      // Ensure profile exists before adding metric
      await ensureProfileExists(user.id);

      // Now safe to insert metric
      const { error } = await supabase
        .from('metric_data_points')
        .insert([metric]);

      if (error) throw error;
      get().fetchCategories();
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },

  updateMetric: async (id, updates) => {
    try {
      const { error } = await supabase
        .from('metric_data_points')
        .update(updates)
        .eq('id', id);

      if (error) throw error;
      get().fetchCategories();
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },

  deleteMetric: async (id) => {
    try {
      const { error } = await supabase
        .from('metric_data_points')
        .delete()
        .eq('id', id);

      if (error) throw error;
      get().fetchCategories();
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },

  updatePreferences: async (categoryId, preferences) => {
    try {
      const { error } = await supabase
        .from('category_preferences')
        .upsert([
          {
            category_id: categoryId,
            ...preferences,
          },
        ]);

      if (error) throw error;
      get().fetchCategories();
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },
}));