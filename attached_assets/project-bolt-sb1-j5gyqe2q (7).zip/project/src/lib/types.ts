import type { RealtimeChannel } from '@supabase/supabase-js';

export interface CategoryDefinition {
  id: string;
  user_id: string;
  name: string;
  description?: string;
  parent_id?: string;
  type: 'metric' | 'group' | 'calculated';
  unit: 'minutes' | 'hours' | 'percentage' | 'boolean' | 'number';
  formula?: string;
  time_period: 'daily' | 'weekly';
  is_active: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
  target_value?: number;
  target_unit: 'hours' | 'boolean' | 'percentage';
  timeframe: 'daily' | 'weekly';
}

export interface MetricDataPoint {
  id: string;
  category_id: string;
  user_id: string;
  actual_value: number;
  target_value: number;
  target_unit: 'hours' | 'boolean' | 'percentage';
  score: number;
  timeframe: 'daily' | 'weekly';
  date: string;
  notes?: string;
  metadata?: Record<string, unknown>;
  created_at: string;
}

export interface CategoryPreference {
  id: string;
  user_id: string;
  category_id: string;
  is_visible: boolean;
  display_type: 'card' | 'chart' | 'progress';
  custom_color?: string;
  weight: number;
  threshold_warning: number;
  threshold_critical: number;
  created_at: string;
  updated_at: string;
}

export interface CategoryWithPreferences extends CategoryDefinition {
  preferences?: CategoryPreference;
  children?: CategoryWithPreferences[];
  metrics?: MetricDataPoint[];
}

export interface RealtimeState {
  channel?: RealtimeChannel;
  isConnected: boolean;
  error: Error | null;
  lastUpdated: string | null;
}

export interface SubcategoryEntry {
  id: string;
  user_id: string;
  subcategory_id: string;
  description: string;
  value: number;
  entry_date: string;
  start_time: string;
  end_time?: string;
  created_at: string;
  updated_at: string;
}

export interface EntryAuditLog {
  id: string;
  entry_id: string;
  operation: string;
  old_data?: Record<string, unknown>;
  new_data?: Record<string, unknown>;
  changed_by: string;
  changed_at: string;
}

export interface DailyMetric {
  id: string;
  user_id: string;
  date: string;
  category: string;
  current_reality: string;
  goal_setting: string;
  sleep_duration: number;
  health_balance: number;
  motivation_level: number;
  sleep_quality: number;
  daily_score: number;
  created_at: string;
}

export interface WeeklySummary {
  avg_score: number;
  avg_motivation: number;
  avg_health: number;
  avg_sleep: number;
  high_score_days: number;
  needs_improvement: string[];
}

export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  daily_prompt_time: string | null;
  preferences: Record<string, unknown>;
  created_at: string;
  updated_at: string;
  xp: number;
  level: number;
  score_streak: number;
  last_activity_date: string | null;
}