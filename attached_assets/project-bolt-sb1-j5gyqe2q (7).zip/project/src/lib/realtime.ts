import { create } from 'zustand';
import { supabase } from './supabase';
import type { RealtimeState, MetricDataPoint } from './types';

interface RealtimeStore extends RealtimeState {
  initialize: () => Promise<void>;
  disconnect: () => void;
  handleMetricUpdate: (payload: { new: MetricDataPoint; old: MetricDataPoint }) => void;
}

export const useRealtime = create<RealtimeStore>((set, get) => ({
  channel: undefined,
  isConnected: false,
  error: null,
  lastUpdated: null,

  initialize: async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Clean up existing subscription if any
      get().disconnect();

      const channel = supabase.channel('metrics_changes')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'metric_data_points',
            filter: `user_id=eq.${user.id}`,
          },
          (payload) => get().handleMetricUpdate(payload as any)
        )
        .subscribe((status) => {
          if (status === 'SUBSCRIBED') {
            set({ isConnected: true, error: null });
          }
        });

      set({ channel, error: null });
    } catch (error) {
      set({ error: error as Error });
    }
  },

  disconnect: () => {
    const { channel } = get();
    if (channel) {
      channel.unsubscribe();
      set({ channel: undefined, isConnected: false });
    }
  },

  handleMetricUpdate: (payload) => {
    set({ lastUpdated: new Date().toISOString() });
    // Trigger store updates based on the payload
    // This will be handled by the metrics store
  },
}));