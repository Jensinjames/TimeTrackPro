import { create } from 'zustand';
import { supabase } from './supabase';
import type { Profile, DailyMetric, WeeklySummary } from './types';

interface LifeTrackingState {
  profile: Profile | null;
  metrics: DailyMetric[];
  weeklySummary: WeeklySummary | null;
  isLoading: boolean;
  error: string | null;
  
  fetchProfile: () => Promise<void>;
  updateProfile: (updates: Partial<Profile>) => Promise<void>;
  fetchMetrics: (startDate?: Date, endDate?: Date) => Promise<void>;
  addMetric: (metric: Omit<DailyMetric, 'id' | 'user_id' | 'created_at' | 'daily_score'>) => Promise<void>;
  updateMetric: (id: string, updates: Partial<DailyMetric>) => Promise<void>;
  fetchWeeklySummary: (weekStartDate: Date) => Promise<void>;
  setDailyPromptTime: (time: string) => Promise<void>;
}

export const useLifeTrackingStore = create<LifeTrackingState>((set, get) => ({
  profile: null,
  metrics: [],
  weeklySummary: null,
  isLoading: false,
  error: null,

  fetchProfile: async () => {
    set({ isLoading: true });
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      set({ profile: data, error: null });
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ isLoading: false });
    }
  },

  updateProfile: async (updates) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id)
        .select()
        .single();

      if (error) throw error;
      get().fetchProfile();
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },

  fetchMetrics: async (startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), endDate = new Date()) => {
    set({ isLoading: true });
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('daily_metrics')
        .select('*')
        .eq('user_id', user.id)
        .gte('date', startDate.toISOString().split('T')[0])
        .lte('date', endDate.toISOString().split('T')[0])
        .order('date', { ascending: false });

      if (error) throw error;
      set({ metrics: data || [], error: null });
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ isLoading: false });
    }
  },

  addMetric: async (metric) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('daily_metrics')
        .insert([{ ...metric, user_id: user.id }])
        .select()
        .single();

      if (error) throw error;
      get().fetchMetrics();
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },

  updateMetric: async (id, updates) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('daily_metrics')
        .update(updates)
        .eq('id', id)
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) throw error;
      get().fetchMetrics();
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },

  fetchWeeklySummary: async (weekStartDate) => {
    set({ isLoading: true });
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .rpc('generate_weekly_summary', {
          user_id: user.id,
          week_start: weekStartDate.toISOString().split('T')[0]
        });

      if (error) throw error;
      set({ weeklySummary: data, error: null });
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ isLoading: false });
    }
  },

  setDailyPromptTime: async (time) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('profiles')
        .update({ daily_prompt_time: time })
        .eq('id', user.id)
        .select()
        .single();

      if (error) throw error;
      get().fetchProfile();
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },
}));