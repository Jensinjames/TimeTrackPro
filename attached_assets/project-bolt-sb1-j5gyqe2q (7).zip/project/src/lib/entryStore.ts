import { create } from 'zustand';
import { supabase } from './supabase';
import type { SubcategoryEntry } from './types';

interface EntryStore {
  entries: SubcategoryEntry[];
  isLoading: boolean;
  error: string | null;
  
  fetchEntries: (startDate: Date, endDate: Date) => Promise<void>;
  addEntry: (entry: Omit<SubcategoryEntry, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateEntry: (id: string, updates: Partial<SubcategoryEntry>) => Promise<void>;
  deleteEntry: (id: string) => Promise<void>;
}

export const useEntryStore = create<EntryStore>((set, get) => ({
  entries: [],
  isLoading: false,
  error: null,

  fetchEntries: async (startDate: Date, endDate: Date) => {
    set({ isLoading: true });
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('subcategory_entries')
        .select('*')
        .eq('user_id', user.id)
        .gte('entry_date', startDate.toISOString().split('T')[0])
        .lte('entry_date', endDate.toISOString().split('T')[0])
        .order('entry_date', { ascending: false });

      if (error) throw error;
      set({ entries: data || [], error: null });
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ isLoading: false });
    }
  },

  addEntry: async (entry) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('subcategory_entries')
        .insert([{ ...entry, user_id: user.id }]);

      if (error) throw error;
      
      // Fetch updated entries
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 7); // Last 7 days
      get().fetchEntries(startDate, new Date());
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },

  updateEntry: async (id: string, updates: Partial<SubcategoryEntry>) => {
    try {
      const { error } = await supabase
        .from('subcategory_entries')
        .update(updates)
        .eq('id', id);

      if (error) throw error;
      
      // Fetch updated entries
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 7); // Last 7 days
      get().fetchEntries(startDate, new Date());
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },

  deleteEntry: async (id: string) => {
    try {
      const { error } = await supabase
        .from('subcategory_entries')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      // Fetch updated entries
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 7); // Last 7 days
      get().fetchEntries(startDate, new Date());
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },
}));