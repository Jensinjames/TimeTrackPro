import { supabase } from './supabase';

export async function ensureProfileExists(userId: string): Promise<void> {
  try {
    // First check if the user exists in auth.users
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError) throw userError;
    if (!user) throw new Error('User not authenticated');

    // Check if user exists in public.users table
    const { data: publicUser, error: publicUserError } = await supabase
      .from('users')
      .select('id')
      .eq('id', userId)
      .maybeSingle();

    if (publicUserError) throw publicUserError;

    // If user doesn't exist in public.users, create them
    if (!publicUser) {
      const { error: insertUserError } = await supabase
        .from('users')
        .insert([{
          id: userId,
          email: user.email,
        }])
        .select()
        .single();

      if (insertUserError) throw insertUserError;
    }

    // Then check if profile exists
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('id')
      .eq('id', userId)
      .maybeSingle();

    if (profileError) throw profileError;

    if (!profile) {
      // Profile doesn't exist, create it with retry logic
      let retryCount = 0;
      const maxRetries = 3;
      
      while (retryCount < maxRetries) {
        try {
          const { error: insertError } = await supabase
            .from('profiles')
            .insert([{ 
              id: userId,
              xp: 0,
              level: 1,
              score_streak: 0
            }])
            .select()
            .single();

          if (!insertError) {
            break; // Success
          }

          // If error is not due to foreign key constraint, throw it
          if (!insertError.message.includes('foreign key constraint')) {
            throw insertError;
          }

          // Wait before retrying
          await new Promise(resolve => setTimeout(resolve, 1000 * (retryCount + 1)));
          retryCount++;

          if (retryCount === maxRetries) {
            throw new Error('Failed to create profile after multiple attempts');
          }
        } catch (error) {
          if (retryCount === maxRetries - 1) throw error;
          retryCount++;
          await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
        }
      }
    }
  } catch (error) {
    console.error('Error in ensureProfileExists:', error);
    throw error;
  }
}