import { evaluate } from 'mathjs';
import { supabase } from './supabase';
import { ensureProfileExists } from './ensureProfileExists';

interface Subcategory {
  id: string;
  formula: string | null;
}

interface SubcategoryEntry {
  value: number;
}

export async function calculateAndSaveDailyMetric(
  userId: string,
  categoryId: string,
  date: string
): Promise<void> {
  try {
    // Ensure profile exists before proceeding
    await ensureProfileExists(userId);

    // Fetch subcategories with their formulas
    const { data: subcategories, error: subcategoriesError } = await supabase
      .from('subcategories')
      .select('id, formula')
      .eq('category_id', categoryId);

    if (subcategoriesError) throw subcategoriesError;

    let totalDuration = 0;

    // Process each subcategory
    for (const subcategory of (subcategories || [])) {
      // Get entries for this subcategory
      const { data: entries, error: entriesError } = await supabase
        .from('subcategory_entries')
        .select('value')
        .eq('subcategory_id', subcategory.id)
        .eq('user_id', userId)
        .eq('entry_date', date);

      if (entriesError) throw entriesError;

      // Sum the values
      const subcategoryTotal = (entries || []).reduce((sum, entry) => sum + entry.value, 0);

      // Apply formula if it exists
      let processedValue = subcategoryTotal;
      if (subcategory.formula) {
        try {
          const formula = subcategory.formula.replace(/value/g, subcategoryTotal.toString());
          processedValue = evaluate(formula);
        } catch (formulaError) {
          console.error(`Formula evaluation failed for subcategory ${subcategory.id}:`, formulaError);
          // Continue with original value if formula fails
        }
      }

      totalDuration += processedValue;
    }

    // Get the category name
    const { data: categoryData, error: categoryError } = await supabase
      .from('categories')
      .select('name')
      .eq('id', categoryId)
      .single();

    if (categoryError) throw categoryError;

    // Get current goal setting
    const { data: currentMetric, error: metricError } = await supabase
      .from('daily_metrics')
      .select('goal_setting')
      .eq('user_id', userId)
      .eq('category', categoryData.name)
      .eq('date', date)
      .single();

    if (metricError && metricError.code !== 'PGRST116') { // Ignore not found error
      throw metricError;
    }

    const goalSetting = currentMetric?.goal_setting ? parseFloat(currentMetric.goal_setting) : 0;
    const scorePercent = goalSetting > 0 ? Math.min((totalDuration / goalSetting) * 100, 100) : 0;

    // Update or insert daily metrics
    const { error: upsertError } = await supabase
      .from('daily_metrics')
      .upsert({
        user_id: userId,
        category: categoryData.name,
        date,
        duration: totalDuration,
        goal_setting: goalSetting.toString(),
        score_percent: scorePercent,
        current_reality: totalDuration.toString(),
        sleep_duration: 0,
        health_balance: 0,
        motivation_level: 0
      }, {
        onConflict: 'user_id,category,date'
      });

    if (upsertError) throw upsertError;

  } catch (error) {
    console.error('Error calculating daily metrics:', error);
    throw error;
  }
}