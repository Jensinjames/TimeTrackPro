import React, { useState, useEffect } from 'react';
import { Plus, X, ChevronDown, ChevronRight, Loader2, Trash2 } from 'lucide-react';
import { useStore } from '../lib/store';
import { cn } from '../lib/utils';

const DEFAULT_CATEGORIES = ['Faith', 'Life', 'Work', 'Health'];

export function CategoryManager() {
  const { 
    categories: rawCategories, 
    subcategories,
    addCategory, 
    deleteCategory,
    addSubcategory,
    deleteSubcategory,
    isLoading, 
    fetchCategories,
    fetchSubcategories 
  } = useStore();
  
  const [newCategory, setNewCategory] = useState('');
  const [error, setError] = useState('');
  const [expandedCategories, setExpandedCategories] = useState<string[]>([]);
  const [newSubcategory, setNewSubcategory] = useState({
    name: '',
    target_value: 0,
  });
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  useEffect(() => {
    fetchCategories();
    fetchSubcategories();
  }, [fetchCategories, fetchSubcategories]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!newCategory.trim()) {
      setError('Category name is required');
      return;
    }

    if (DEFAULT_CATEGORIES.includes(newCategory.trim())) {
      setError('Cannot add default category');
      return;
    }

    if (rawCategories.some(cat => cat.name.toLowerCase() === newCategory.toLowerCase())) {
      setError('Category already exists');
      return;
    }

    try {
      await addCategory({
        name: newCategory.trim(),
      });
      setNewCategory('');
    } catch (err) {
      setError('Failed to add category');
    }
  };

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev =>
      prev.includes(categoryId)
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleAddSubcategory = async (categoryId: string) => {
    if (!newSubcategory.name.trim()) {
      setError('Subcategory name is required');
      return;
    }

    try {
      await addSubcategory({
        category_id: categoryId,
        name: newSubcategory.name.trim(),
        target_value: newSubcategory.target_value,
        target_unit: 'minutes',
        timeframe: 'daily'
      });
      setNewSubcategory({
        name: '',
        target_value: 0,
      });
      setSelectedCategory(null);
    } catch (err) {
      setError('Failed to add subcategory');
    }
  };

  const getCategorySubcategories = (categoryId: string) => {
    return subcategories.filter(sub => sub.category_id === categoryId);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-lg">
        <h3 className="text-lg font-semibold mb-4">Categories</h3>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1">
              <input
                type="text"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="New category name"
                className={cn(
                  "w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
                  error ? "border-red-500" : "border-gray-300"
                )}
              />
              {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
            </div>
            <button
              type="submit"
              disabled={isLoading}
              className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors disabled:bg-blue-300 flex items-center gap-2"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Adding...
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  Add
                </>
              )}
            </button>
          </div>
        </form>

        <div className="mt-6 space-y-2">
          <h4 className="text-sm font-medium text-gray-500 mb-3">Default Categories</h4>
          {DEFAULT_CATEGORIES.map((category) => (
            <div key={category} className="group">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => toggleCategory(category)}
                    className="p-1 hover:bg-gray-200 rounded"
                  >
                    {expandedCategories.includes(category) ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>
                  <span className="font-medium">{category}</span>
                </div>
                <span className="text-sm text-gray-500">Default</span>
              </div>
              
              {expandedCategories.includes(category) && (
                <div className="ml-8 mt-2 space-y-2">
                  {getCategorySubcategories(category).map((subcategory) => (
                    <div key={subcategory.id} className="flex items-center justify-between p-2 bg-gray-100 rounded-md">
                      <div>
                        <span className="text-sm font-medium">{subcategory.name}</span>
                        <span className="text-xs text-gray-500 ml-2">
                          {subcategory.target_value} minutes/day
                        </span>
                      </div>
                      <button
                        onClick={() => deleteSubcategory(subcategory.id)}
                        className="text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  
                  <button
                    onClick={() => setSelectedCategory(category)}
                    className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-700"
                  >
                    <Plus className="w-4 h-4" />
                    Add Subcategory
                  </button>
                  
                  {selectedCategory === category && (
                    <div className="p-3 bg-gray-100 rounded-md">
                      <input
                        type="text"
                        value={newSubcategory.name}
                        onChange={(e) => setNewSubcategory(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Subcategory name"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 mb-2"
                      />
                      <div className="mb-2">
                        <input
                          type="number"
                          value={newSubcategory.target_value}
                          onChange={(e) => setNewSubcategory(prev => ({ ...prev, target_value: Number(e.target.value) }))}
                          placeholder="Target minutes per day"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => setSelectedCategory(null)}
                          className="px-3 py-1 text-sm text-gray-600 hover:text-gray-800"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={() => handleAddSubcategory(category)}
                          className="px-3 py-1 text-sm bg-blue-500 text-white rounded-md hover:bg-blue-600"
                        >
                          Add
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        {rawCategories.length > 0 && (
          <div className="mt-6 space-y-2">
            <h4 className="text-sm font-medium text-gray-500 mb-3">Custom Categories</h4>
            {rawCategories.map((category) => (
              <div key={category.id} className="group">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => toggleCategory(category.id)}
                      className="p-1 hover:bg-gray-200 rounded"
                    >
                      {expandedCategories.includes(category.id) ? (
                        <ChevronDown className="w-4 h-4" />
                      ) : (
                        <ChevronRight className="w-4 h-4" />
                      )}
                    </button>
                    <span className="font-medium">{category.name}</span>
                  </div>
                  <button
                    onClick={() => deleteCategory(category.id)}
                    className="text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {expandedCategories.includes(category.id) && (
                  <div className="ml-8 mt-2 space-y-2">
                    {getCategorySubcategories(category.id).map((subcategory) => (
                      <div key={subcategory.id} className="flex items-center justify-between p-2 bg-gray-100 rounded-md">
                        <div>
                          <span className="text-sm font-medium">{subcategory.name}</span>
                          <span className="text-xs text-gray-500 ml-2">
                            {subcategory.target_value} minutes/day
                          </span>
                        </div>
                        <button
                          onClick={() => deleteSubcategory(subcategory.id)}
                          className="text-gray-400 hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}

                    <button
                      onClick={() => setSelectedCategory(category.id)}
                      className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-700"
                    >
                      <Plus className="w-4 h-4" />
                      Add Subcategory
                    </button>

                    {selectedCategory === category.id && (
                      <div className="p-3 bg-gray-100 rounded-md">
                        <input
                          type="text"
                          value={newSubcategory.name}
                          onChange={(e) => setNewSubcategory(prev => ({ ...prev, name: e.target.value }))}
                          placeholder="Subcategory name"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 mb-2"
                        />
                        <div className="mb-2">
                          <input
                            type="number"
                            value={newSubcategory.target_value}
                            onChange={(e) => setNewSubcategory(prev => ({ ...prev, target_value: Number(e.target.value) }))}
                            placeholder="Target minutes per day"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => setSelectedCategory(null)}
                            className="px-3 py-1 text-sm text-gray-600 hover:text-gray-800"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => handleAddSubcategory(category.id)}
                            className="px-3 py-1 text-sm bg-blue-500 text-white rounded-md hover:bg-blue-600"
                          >
                            Add
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}