import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Loader2 } from 'lucide-react';
import { useStore } from '../lib/store';
import { cn } from '../lib/utils';

interface Goal {
  id: string;
  categoryId: string;
  name: string;
  target: number;
  timeframe: 'daily' | 'weekly' | 'monthly';
  unit: string;
}

export function GoalsManager() {
  const { categories, isLoading } = useStore();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [newGoal, setNewGoal] = useState({
    categoryId: '',
    name: '',
    target: 0,
    timeframe: 'daily' as const,
    unit: 'hours',
  });
  const [error, setError] = useState('');

  const timeframes = [
    { value: 'daily', label: 'Daily' },
    { value: 'weekly', label: 'Weekly' },
    { value: 'monthly', label: 'Monthly' },
  ];

  const units = [
    { value: 'hours', label: 'Hours' },
    { value: 'tasks', label: 'Tasks' },
    { value: 'points', label: 'Points' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!newGoal.categoryId || !newGoal.name || newGoal.target <= 0) {
      setError('Please fill in all required fields');
      return;
    }

    const goal: Goal = {
      id: crypto.randomUUID(),
      ...newGoal,
    };

    setGoals([...goals, goal]);
    setNewGoal({
      categoryId: '',
      name: '',
      target: 0,
      timeframe: 'daily',
      unit: 'hours',
    });
  };

  const deleteGoal = (goalId: string) => {
    setGoals(goals.filter(goal => goal.id !== goalId));
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Category
            </label>
            <select
              value={newGoal.categoryId}
              onChange={(e) => setNewGoal(prev => ({ ...prev, categoryId: e.target.value }))}
              className={cn(
                "w-full px-3 py-2 border rounded-lg",
                "focus:outline-none focus:ring-2 focus:ring-blue-500",
                error && !newGoal.categoryId ? "border-red-500" : "border-gray-300"
              )}
            >
              <option value="">Select a category</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Goal Name
            </label>
            <input
              type="text"
              value={newGoal.name}
              onChange={(e) => setNewGoal(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Enter goal name"
              className={cn(
                "w-full px-3 py-2 border rounded-lg",
                "focus:outline-none focus:ring-2 focus:ring-blue-500",
                error && !newGoal.name ? "border-red-500" : "border-gray-300"
              )}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Target Value
            </label>
            <input
              type="number"
              min="0"
              step="0.5"
              value={newGoal.target}
              onChange={(e) => setNewGoal(prev => ({ ...prev, target: parseFloat(e.target.value) }))}
              className={cn(
                "w-full px-3 py-2 border rounded-lg",
                "focus:outline-none focus:ring-2 focus:ring-blue-500",
                error && newGoal.target <= 0 ? "border-red-500" : "border-gray-300"
              )}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Timeframe
            </label>
            <select
              value={newGoal.timeframe}
              onChange={(e) => setNewGoal(prev => ({ ...prev, timeframe: e.target.value as 'daily' | 'weekly' | 'monthly' }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {timeframes.map((timeframe) => (
                <option key={timeframe.value} value={timeframe.value}>
                  {timeframe.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Unit
            </label>
            <select
              value={newGoal.unit}
              onChange={(e) => setNewGoal(prev => ({ ...prev, unit: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {units.map((unit) => (
                <option key={unit.value} value={unit.value}>
                  {unit.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {error && (
          <p className="text-red-500 text-sm">{error}</p>
        )}

        <div className="flex justify-end">
          <button
            type="submit"
            className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Goal
          </button>
        </div>
      </form>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-900">Current Goals</h3>
        {goals.length === 0 ? (
          <p className="text-gray-500 text-center py-4">No goals added yet</p>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {goals.map((goal) => (
              <div
                key={goal.id}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div>
                  <h4 className="font-medium text-gray-900">{goal.name}</h4>
                  <p className="text-sm text-gray-500">
                    {goal.target} {goal.unit} {goal.timeframe}
                  </p>
                </div>
                <button
                  onClick={() => deleteGoal(goal.id)}
                  className="text-gray-400 hover:text-red-500 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}