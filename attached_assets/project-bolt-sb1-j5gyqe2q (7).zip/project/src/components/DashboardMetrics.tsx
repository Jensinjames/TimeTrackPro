import React from 'react';
import { Activity, Brain, Heart, Scale } from 'lucide-react';
import { MetricCard } from './MetricCard';
import type { CategoryWithPreferences } from '../lib/types';

interface DashboardMetricsProps {
  categories: CategoryWithPreferences[];
}

export function DashboardMetrics({ categories }: DashboardMetricsProps) {
  const calculateOverallScore = () => {
    if (!categories.length) return 0;
    
    const totalScore = categories.reduce((acc, category) => {
      const latestMetric = category.metrics?.[0];
      return acc + (latestMetric?.value || 0);
    }, 0);
    
    return Math.round(totalScore / categories.length);
  };

  const calculateFocusTime = () => {
    const focusCategory = categories.find(c => c.type === 'metric' && c.unit === 'hours');
    const latestMetric = focusCategory?.metrics?.[0];
    return latestMetric?.value || 0;
  };

  const calculateHealthIndex = () => {
    const healthCategories = categories.filter(c => 
      c.type === 'metric' && c.unit === 'percentage' && c.name.toLowerCase().includes('health')
    );
    
    if (!healthCategories.length) return 0;
    
    const totalHealth = healthCategories.reduce((acc, category) => {
      const latestMetric = category.metrics?.[0];
      return acc + (latestMetric?.value || 0);
    }, 0);
    
    return Math.round(totalHealth / healthCategories.length);
  };

  const calculateBalanceScore = () => {
    const workCategory = categories.find(c => c.name.toLowerCase() === 'work');
    const lifeCategory = categories.find(c => c.name.toLowerCase() === 'life');
    
    const workScore = workCategory?.metrics?.[0]?.value || 0;
    const lifeScore = lifeCategory?.metrics?.[0]?.value || 0;
    
    return Math.round((workScore + lifeScore) / 2);
  };

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
      <MetricCard
        type="simple"
        title="Activity Score"
        value={`${calculateOverallScore()}%`}
        icon={Activity}
        description="Overall activity performance"
        color="bg-blue-500"
      />
      <MetricCard
        type="simple"
        title="Focus Time"
        value={`${calculateFocusTime()}h`}
        icon={Brain}
        description="Daily focused work time"
        color="bg-purple-500"
      />
      <MetricCard
        type="simple"
        title="Health Index"
        value={`${calculateHealthIndex()}%`}
        icon={Heart}
        description="Overall health metrics"
        color="bg-green-500"
      />
      <MetricCard
        type="simple"
        title="Balance Score"
        value={`${calculateBalanceScore()}%`}
        icon={Scale}
        description="Work-life balance rating"
        color="bg-indigo-500"
      />
    </div>
  );
}