import React, { useEffect } from 'react';
import { useStore } from '../lib/store';
import { useParams } from 'react-router-dom';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { Loader2 } from 'lucide-react';

export function CategoryPage() {
  const { category } = useParams<{ category: string }>();
  const { metrics, isLoading, error, fetchMetrics } = useStore();

  useEffect(() => {
    fetchMetrics();
  }, [fetchMetrics]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-red-500 text-center p-4">
        Error loading metrics: {error}
      </div>
    );
  }

  const categoryMetrics = metrics.filter(
    (metric) => metric.category.toLowerCase() === category?.toLowerCase()
  );

  const timelineData = categoryMetrics
    .map((metric) => ({
      date: metric.date.split('T')[0],
      'Health Balance': metric.health_balance,
      'Motivation Level': metric.motivation_level,
      'Sleep Duration': metric.sleep_duration,
    }))
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="space-y-8">
      <div className="bg-white p-6 rounded-xl shadow-lg">
        <h2 className="text-2xl font-semibold mb-6 capitalize">{category} Metrics</h2>
        
        <div className="h-96">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={timelineData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="Health Balance"
                stroke="#2563eb"
                strokeWidth={2}
              />
              <Line
                type="monotone"
                dataKey="Motivation Level"
                stroke="#16a34a"
                strokeWidth={2}
              />
              <Line
                type="monotone"
                dataKey="Sleep Duration"
                stroke="#dc2626"
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {categoryMetrics.map((metric) => (
          <div key={metric.id} className="bg-white p-6 rounded-xl shadow-lg">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-lg font-semibold">
                {new Date(metric.date).toLocaleDateString()}
              </h3>
            </div>
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-medium text-gray-500">Current Reality</h4>
                <p className="mt-1 text-gray-900">{metric.current_reality}</p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-gray-500">Goal Setting</h4>
                <p className="mt-1 text-gray-900">{metric.goal_setting}</p>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Sleep</h4>
                  <p className="mt-1 text-gray-900">{metric.sleep_duration}h</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Health</h4>
                  <p className="mt-1 text-gray-900">{metric.health_balance}%</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Motivation</h4>
                  <p className="mt-1 text-gray-900">{metric.motivation_level}%</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}