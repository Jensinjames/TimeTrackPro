import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Loader2, Mail, Lock, AlertCircle } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { cn } from '../lib/utils';

type AuthMode = 'login' | 'signup' | 'reset-password';

export function AuthPanel() {
  const navigate = useNavigate();
  const location = useLocation();
  const { signIn, signUp, resetPassword, isLoading } = useAuth();
  
  const [mode, setMode] = useState<AuthMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    try {
      if (mode === 'reset-password') {
        const { error } = await resetPassword(email);
        if (error) throw error;
        setSuccessMessage('Password reset instructions have been sent to your email');
        return;
      }

      const { error } = mode === 'signup' 
        ? await signUp(email, password)
        : await signIn(email, password);

      if (error) throw error;

      if (mode === 'signup') {
        setSuccessMessage('Please check your email to verify your account');
      } else {
        const returnUrl = new URLSearchParams(location.search).get('returnTo') || '/';
        navigate(returnUrl);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            {mode === 'login' && 'Sign in to your account'}
            {mode === 'signup' && 'Create your account'}
            {mode === 'reset-password' && 'Reset your password'}
          </h2>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-md p-4 flex items-start">
            <AlertCircle className="w-5 h-5 text-red-500 mt-0.5 mr-3 flex-shrink-0" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        {successMessage && (
          <div className="bg-green-50 border border-green-200 rounded-md p-4">
            <p className="text-sm text-green-700">{successMessage}</p>
          </div>
        )}

        <form className="mt-8 space-y-6" onSubmit={handleSubmit} id="auth-form">
          <div className="rounded-md shadow-sm -space-y-px">
            <div>
              <label htmlFor="email-address" className="sr-only">
                Email address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  id="email-address"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={cn(
                    "appearance-none rounded-t-md relative block w-full px-10 py-2 border",
                    "border-gray-300 placeholder-gray-500 text-gray-900",
                    "focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm"
                  )}
                  placeholder="Email address"
                />
              </div>
            </div>
            {mode !== 'reset-password' && (
              <div>
                <label htmlFor="current-password" className="sr-only">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    id="current-password"
                    name="current-password"
                    type="password"
                    autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className={cn(
                      "appearance-none rounded-b-md relative block w-full px-10 py-2 border",
                      "border-gray-300 placeholder-gray-500 text-gray-900",
                      "focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm"
                    )}
                    placeholder="Password"
                    minLength={6}
                  />
                </div>
              </div>
            )}
          </div>

          <div>
            <button
              type="submit"
              id="submit-button"
              name="submit"
              disabled={isLoading}
              className={cn(
                "group relative w-full flex justify-center py-2 px-4 border border-transparent",
                "text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700",
                "focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500",
                "disabled:opacity-50 disabled:cursor-not-allowed"
              )}
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  {mode === 'login' && 'Sign in'}
                  {mode === 'signup' && 'Create account'}
                  {mode === 'reset-password' && 'Send reset instructions'}
                </>
              )}
            </button>
          </div>

          <div className="flex items-center justify-between">
            {mode === 'login' && (
              <>
                <button
                  type="button"
                  id="signup-button"
                  name="signup"
                  onClick={() => setMode('signup')}
                  className="text-sm font-medium text-blue-600 hover:text-blue-500"
                >
                  Create an account
                </button>
                <button
                  type="button"
                  id="reset-password-button"
                  name="reset-password"
                  onClick={() => setMode('reset-password')}
                  className="text-sm font-medium text-blue-600 hover:text-blue-500"
                >
                  Forgot password?
                </button>
              </>
            )}
            {mode !== 'login' && (
              <button
                type="button"
                id="back-to-login-button"
                name="back-to-login"
                onClick={() => setMode('login')}
                className="text-sm font-medium text-blue-600 hover:text-blue-500"
              >
                Back to sign in
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}