import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Settings,
  ChevronLeft,
  Menu,
  PlusCircle,
  Clock
} from 'lucide-react';
import { cn } from '../lib/utils';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
  { icon: PlusCircle, label: 'Daily Input', path: '/daily' },
  { icon: Clock, label: 'Time Entries', path: '/entries' },
  { icon: Settings, label: 'Settings', path: '/settings' },
];

export function Sidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const location = useLocation();

  return (
    <>
      <div 
        className={cn(
          "fixed top-0 left-0 bottom-0 bg-white border-r border-gray-200 transition-all duration-300 ease-in-out z-20",
          isCollapsed ? "w-16" : "w-64"
        )}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <div className={cn("flex items-center gap-2", isCollapsed && "hidden")}>
            <LayoutDashboard className="w-8 h-8 text-blue-500" />
            <span className="text-xl font-bold">Rollen</span>
          </div>
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
          >
            {isCollapsed ? (
              <Menu className="w-5 h-5" />
            ) : (
              <ChevronLeft className="w-5 h-5" />
            )}
          </button>
        </div>
        
        <nav className="p-4 space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors",
                  isActive && "bg-blue-50 text-blue-700 font-medium"
                )
              }
              end={item.path === '/'}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              <span className={cn("transition-opacity duration-300", isCollapsed && "opacity-0 hidden")}>
                {item.label}
              </span>
            </NavLink>
          ))}
        </nav>
      </div>
      
      <div 
        className={cn(
          "fixed inset-0 bg-black/20 transition-opacity duration-300 z-10 lg:hidden",
          isCollapsed ? "opacity-0 pointer-events-none" : "opacity-100"
        )}
        onClick={() => setIsCollapsed(true)}
      />
    </>
  );
}