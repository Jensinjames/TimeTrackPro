import React, { useEffect } from 'react';
import { useStore } from '../lib/store';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { Loader2 } from 'lucide-react';

const COLORS = {
  Faith: '#16a34a', // green-600
  Life: '#ca8a04', // yellow-600
  Work: '#dc2626', // red-600
  Health: '#db2777', // pink-600
};

export function AnalyticsDashboard() {
  const { metrics, isLoading, error, fetchMetrics } = useStore();

  useEffect(() => {
    fetchMetrics();
  }, [fetchMetrics]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-red-500 text-center p-4">
        Error loading metrics: {error}
      </div>
    );
  }

  if (!metrics || metrics.length === 0) {
    return (
      <div className="text-gray-500 text-center p-4">
        No metrics data available
      </div>
    );
  }

  const categoryData = Object.entries(
    metrics.reduce((acc, metric) => {
      if (metric.category) {
        acc[metric.category] = (acc[metric.category] || 0) + 1;
      }
      return acc;
    }, {} as Record<string, number>)
  ).map(([name, value]) => ({ name, value }));

  const timelineData = Object.values(
    metrics.reduce((acc, metric) => {
      if (metric.date) {
        const date = metric.date.split('T')[0];
        if (!acc[date]) {
          acc[date] = {
            date,
            'Health Balance': 0,
            'Motivation Level': 0,
            count: 0,
          };
        }
        if (typeof metric.health_balance === 'number') {
          acc[date]['Health Balance'] += metric.health_balance;
        }
        if (typeof metric.motivation_level === 'number') {
          acc[date]['Motivation Level'] += metric.motivation_level;
        }
        acc[date].count += 1;
      }
      return acc;
    }, {} as Record<string, any>)
  ).map(entry => ({
    date: entry.date,
    'Health Balance': Math.round(entry['Health Balance'] / entry.count),
    'Motivation Level': Math.round(entry['Motivation Level'] / entry.count),
  }))
  .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  if (categoryData.length === 0 || timelineData.length === 0) {
    return (
      <div className="text-gray-500 text-center p-4">
        Not enough data to display charts
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h2 className="text-xl font-semibold mb-4">Category Distribution</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label
                >
                  {categoryData.map((entry) => (
                    <Cell
                      key={entry.name}
                      fill={COLORS[entry.name as keyof typeof COLORS]}
                    />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h2 className="text-xl font-semibold mb-4">Metrics Timeline</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timelineData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="Health Balance"
                  stroke="#2563eb"
                  strokeWidth={2}
                />
                <Line
                  type="monotone"
                  dataKey="Motivation Level"
                  stroke="#16a34a"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}