import React, { useState } from 'react';
import { Eye, EyeOff, Check } from 'lucide-react';
import { cn } from '../lib/utils';

interface DisplayOption {
  id: string;
  label: string;
  description: string;
  type: 'chart' | 'number' | 'progress';
}

const displayOptions: DisplayOption[] = [
  {
    id: 'daily-progress',
    label: 'Daily Progress',
    description: 'Show daily goal completion as progress bars',
    type: 'progress',
  },
  {
    id: 'weekly-chart',
    label: 'Weekly Overview',
    description: 'Display weekly data in a line chart',
    type: 'chart',
  },
  {
    id: 'monthly-summary',
    label: 'Monthly Summary',
    description: 'Show monthly totals as numbers',
    type: 'number',
  },
];

export function DisplaySettings() {
  const [visibleItems, setVisibleItems] = useState<string[]>(['daily-progress', 'weekly-chart']);
  const [selectedColors, setSelectedColors] = useState<Record<string, string>>({
    success: '#22c55e',
    warning: '#eab308',
    danger: '#ef4444',
  });

  const toggleVisibility = (id: string) => {
    setVisibleItems(prev =>
      prev.includes(id)
        ? prev.filter(item => item !== id)
        : [...prev, id]
    );
  };

  const updateColor = (key: string, value: string) => {
    setSelectedColors(prev => ({
      ...prev,
      [key]: value,
    }));
  };

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Dashboard Items</h3>
        <div className="space-y-4">
          {displayOptions.map((option) => (
            <div
              key={option.id}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div>
                <div className="flex items-center gap-3">
                  <h4 className="font-medium text-gray-900">{option.label}</h4>
                  <span className="px-2 py-1 text-xs font-medium text-gray-500 bg-gray-100 rounded-full">
                    {option.type}
                  </span>
                </div>
                <p className="text-sm text-gray-500 mt-1">{option.description}</p>
              </div>
              <button
                onClick={() => toggleVisibility(option.id)}
                className={cn(
                  "p-2 rounded-lg transition-colors",
                  visibleItems.includes(option.id)
                    ? "text-blue-600 bg-blue-50 hover:bg-blue-100"
                    : "text-gray-400 hover:text-gray-600"
                )}
              >
                {visibleItems.includes(option.id) ? (
                  <Eye className="w-5 h-5" />
                ) : (
                  <EyeOff className="w-5 h-5" />
                )}
              </button>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Color Scheme</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {Object.entries(selectedColors).map(([key, value]) => (
            <div key={key} className="space-y-2">
              <label className="block text-sm font-medium text-gray-700 capitalize">
                {key} Color
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={value}
                  onChange={(e) => updateColor(key, e.target.value)}
                  className="w-8 h-8 rounded cursor-pointer"
                />
                <input
                  type="text"
                  value={value}
                  onChange={(e) => updateColor(key, e.target.value)}
                  className="flex-1 px-3 py-1 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-end pt-6 border-t">
        <button
          className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
        >
          <Check className="w-4 h-4" />
          Save Changes
        </button>
      </div>
    </div>
  );
}