import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Pencil } from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';
import { EditMetricModal } from './EditMetricModal';
import { cn } from '../lib/utils';

interface ValueCardProps {
  title: string;
  icon: React.ElementType;
  reality: {
    description: string;
    metrics: Array<{ label: string; value: string | number }>;
  };
  goal: {
    description: string;
    metrics: Array<{ label: string; value: string | number }>;
  };
  color: string;
  chartData: Array<{ name: string; value: number }>;
}

const COLORS = {
  'Faith': ['#16a34a', '#22c55e', '#4ade80', '#86efac'],
  'Life': ['#ca8a04', '#eab308', '#facc15', '#fde047'],
  'Work': ['#dc2626', '#ef4444', '#f87171', '#fca5a5'],
  'Health': ['#db2777', '#ec4899', '#f472b6', '#f9a8d4'],
};

export function ValueCard({ 
  title, 
  icon: Icon, 
  reality, 
  goal, 
  color, 
  chartData 
}: ValueCardProps) {
  const [isEditModalOpen, setIsEditModalOpen] = React.useState(false);
  
  const getColors = (title: string) => {
    return COLORS[title as keyof typeof COLORS] || ['#6366f1', '#818cf8', '#a5b4fc', '#c7d2fe'];
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl shadow-lg overflow-hidden"
    >
      <div className={cn(color, "p-4 flex items-center justify-between")}>
        <div className="flex items-center gap-3">
          <Icon className="w-6 h-6 text-white" />
          <h3 className="text-lg font-semibold text-white">{title}</h3>
        </div>
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsEditModalOpen(true)}
          className="text-white/80 hover:text-white transition-colors p-1"
        >
          <Pencil className="w-4 h-4" />
        </motion.button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-gray-200">
        <div className="p-4">
          <h4 className="text-sm font-medium text-gray-500 mb-2">Current Reality</h4>
          <p className="text-sm text-gray-600 mb-4">{reality.description}</p>
          <div className="space-y-2">
            {reality.metrics.map((metric, index) => (
              <div key={index} className="flex justify-between items-center">
                <span className="text-sm text-gray-600">{metric.label}</span>
                <span className="text-sm font-medium">{metric.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="p-4">
          <h4 className="text-sm font-medium text-gray-500 mb-2">Goals</h4>
          <p className="text-sm text-gray-600 mb-4">{goal.description}</p>
          <div className="space-y-2">
            {goal.metrics.map((metric, index) => (
              <div key={index} className="flex justify-between items-center">
                <span className="text-sm text-gray-600">{metric.label}</span>
                <span className="text-sm font-medium">{metric.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4 border-t border-gray-200">
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={2}
                dataKey="value"
              >
                {chartData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`}
                    fill={getColors(title)[index % getColors(title).length]}
                  />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value: number) => `${value}%`}
                contentStyle={{
                  backgroundColor: 'white',
                  border: '1px solid #e2e8f0',
                  borderRadius: '0.5rem',
                  padding: '0.5rem',
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <motion.button
          whileHover={{ x: 4 }}
          className="w-full flex items-center justify-center gap-2 text-sm font-medium text-blue-600 hover:text-blue-700 transition-colors mt-4"
        >
          View Details
          <ArrowRight className="w-4 h-4" />
        </motion.button>
      </div>

      <EditMetricModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        category={title}
        initialValues={{
          goalHours: 8,
          actualHours: 6,
        }}
      />
    </motion.div>
  );
}