import React, { useState, useEffect } from 'react';
import { format, parseISO } from 'date-fns';
import DatePicker from 'react-datepicker';
import { Clock, Plus, Trash2, Save, Loader2, AlertCircle } from 'lucide-react';
import { useEntryStore } from '../lib/entryStore';
import { useCategoryStore } from '../lib/categoryStore';
import { cn } from '../lib/utils';
import type { SubcategoryEntry } from '../lib/types';

interface TimeEntryFormData {
  subcategory_id: string;
  description: string;
  value: number;
  entry_date: Date;
  start_time: Date;
  end_time?: Date;
}

const initialFormData: TimeEntryFormData = {
  subcategory_id: '',
  description: '',
  value: 0,
  entry_date: new Date(),
  start_time: new Date(),
};

export function TimeEntryManager() {
  const { entries, isLoading, error, fetchEntries, addEntry, deleteEntry } = useEntryStore();
  const { categories, fetchCategories } = useCategoryStore();
  const [formData, setFormData] = useState<TimeEntryFormData>(initialFormData);
  const [formError, setFormError] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState<[Date, Date]>([
    new Date(new Date().setDate(new Date().getDate() - 7)),
    new Date()
  ]);

  useEffect(() => {
    fetchCategories();
    fetchEntries(dateRange[0], dateRange[1]);
  }, [fetchCategories, fetchEntries, dateRange]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!formData.subcategory_id) {
      setFormError('Please select a subcategory');
      return;
    }

    if (!formData.description.trim()) {
      setFormError('Description is required');
      return;
    }

    if (formData.value <= 0) {
      setFormError('Duration must be greater than 0');
      return;
    }

    try {
      await addEntry({
        subcategory_id: formData.subcategory_id,
        description: formData.description.trim(),
        value: formData.value,
        entry_date: format(formData.entry_date, 'yyyy-MM-dd'),
        start_time: formData.start_time.toISOString(),
        end_time: formData.end_time?.toISOString(),
      });

      setFormData(initialFormData);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to add entry');
    }
  };

  const handleDelete = async (entryId: string) => {
    try {
      await deleteEntry(entryId);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to delete entry');
    }
  };

  const getAllSubcategories = () => {
    const subcategories: { id: string; name: string; category: string }[] = [];
    categories.forEach(category => {
      category.children?.forEach(subcategory => {
        subcategories.push({
          id: subcategory.id,
          name: subcategory.name,
          category: category.name
        });
      });
    });
    return subcategories;
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-lg">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Time Entries</h2>

        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start">
            <AlertCircle className="w-5 h-5 text-red-500 mt-0.5 mr-3" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Subcategory
              </label>
              <select
                value={formData.subcategory_id}
                onChange={e => setFormData(prev => ({ ...prev, subcategory_id: e.target.value }))}
                className={cn(
                  "w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500",
                  formError && !formData.subcategory_id ? "border-red-500" : "border-gray-300"
                )}
              >
                <option value="">Select a subcategory</option>
                {getAllSubcategories().map(sub => (
                  <option key={sub.id} value={sub.id}>
                    {sub.category} - {sub.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date
              </label>
              <div className="relative">
                <DatePicker
                  selected={formData.entry_date}
                  onChange={(date: Date) => setFormData(prev => ({ ...prev, entry_date: date }))}
                  maxDate={new Date()}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  dateFormat="MMM d, yyyy"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <input
              type="text"
              value={formData.description}
              onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
              className={cn(
                "w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500",
                formError && !formData.description ? "border-red-500" : "border-gray-300"
              )}
              placeholder="What did you work on?"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Duration (minutes)
              </label>
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="number"
                  min="0"
                  value={formData.value}
                  onChange={e => setFormData(prev => ({ ...prev, value: Number(e.target.value) }))}
                  className={cn(
                    "w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500",
                    formError && formData.value <= 0 ? "border-red-500" : "border-gray-300"
                  )}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Start Time
              </label>
              <DatePicker
                selected={formData.start_time}
                onChange={(date: Date) => setFormData(prev => ({ ...prev, start_time: date }))}
                showTimeSelect
                showTimeSelectOnly
                timeIntervals={15}
                timeCaption="Time"
                dateFormat="h:mm aa"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                End Time (optional)
              </label>
              <DatePicker
                selected={formData.end_time}
                onChange={(date: Date | null) => setFormData(prev => ({ ...prev, end_time: date || undefined }))}
                showTimeSelect
                showTimeSelectOnly
                timeIntervals={15}
                timeCaption="Time"
                dateFormat="h:mm aa"
                isClearable
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {formError && (
            <p className="text-sm text-red-600">{formError}</p>
          )}

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="w-5 h-5" />
                  Save Entry
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-medium text-gray-900">Recent Entries</h3>
          <div className="flex items-center gap-4">
            <DatePicker
              selected={dateRange[0]}
              onChange={(date: Date) => setDateRange([date, dateRange[1]])}
              selectsStart
              startDate={dateRange[0]}
              endDate={dateRange[1]}
              maxDate={dateRange[1]}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              dateFormat="MMM d, yyyy"
            />
            <DatePicker
              selected={dateRange[1]}
              onChange={(date: Date) => setDateRange([dateRange[0], date])}
              selectsEnd
              startDate={dateRange[0]}
              endDate={dateRange[1]}
              minDate={dateRange[0]}
              maxDate={new Date()}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              dateFormat="MMM d, yyyy"
            />
          </div>
        </div>

        <div className="space-y-4">
          {entries.map(entry => (
            <div
              key={entry.id}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{entry.description}</span>
                  <span className="text-sm text-gray-500">
                    ({entry.value} minutes)
                  </span>
                </div>
                <div className="text-sm text-gray-500">
                  {format(parseISO(entry.entry_date), 'MMM d, yyyy')} at{' '}
                  {format(parseISO(entry.start_time), 'h:mm a')}
                  {entry.end_time && ` - ${format(parseISO(entry.end_time), 'h:mm a')}`}
                </div>
              </div>
              <button
                onClick={() => handleDelete(entry.id)}
                className="text-gray-400 hover:text-red-500 transition-colors"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          ))}

          {entries.length === 0 && (
            <p className="text-center text-gray-500 py-4">
              No entries found for the selected date range
            </p>
          )}
        </div>
      </div>
    </div>
  );
}