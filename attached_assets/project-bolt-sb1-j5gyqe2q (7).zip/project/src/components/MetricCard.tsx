import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface BaseMetricCardProps {
  title: string;
  icon: LucideIcon;
  description: string;
  color: string;
}

interface CategoryMetricCardProps extends BaseMetricCardProps {
  type: 'category';
  goalHours: number;
  actualHours: number;
}

interface SimpleMetricCardProps extends BaseMetricCardProps {
  type: 'simple';
  value: string;
}

type MetricCardProps = CategoryMetricCardProps | SimpleMetricCardProps;

export function MetricCard(props: MetricCardProps) {
  const { title, icon: Icon, description, color } = props;

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <div className="flex items-start gap-4">
        <div className={`${color} p-3 rounded-lg`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <h3 className="text-sm font-medium text-gray-600">{title}</h3>
          </div>
          {props.type === 'category' ? (
            <div className="mt-2 space-y-2">
              <div className="flex justify-between items-baseline">
                <span className="text-sm text-gray-500">Goal</span>
                <span className="text-lg font-semibold">{props.goalHours}h</span>
              </div>
              <div className="flex justify-between items-baseline">
                <span className="text-sm text-gray-500">Actual</span>
                <span className="text-lg font-semibold">{props.actualHours}h</span>
              </div>
              <div className="relative pt-1">
                <div className="flex mb-2 items-center justify-between">
                  <div>
                    <span className="text-xs font-semibold inline-block text-gray-600">
                      Progress
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-semibold inline-block text-gray-600">
                      {Math.round((props.actualHours / props.goalHours) * 100)}%
                    </span>
                  </div>
                </div>
                <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                  <div
                    style={{ width: `${Math.min((props.actualHours / props.goalHours) * 100, 100)}%` }}
                    className={`shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center transition-all duration-500 ${color}`}
                  />
                </div>
              </div>
            </div>
          ) : (
            <div className="mt-2">
              <p className="text-2xl font-semibold">{props.value}</p>
              <p className="text-sm text-gray-500 mt-1">{description}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}