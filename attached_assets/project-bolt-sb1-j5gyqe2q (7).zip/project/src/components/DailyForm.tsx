import { DailyInputForm } from './DailyInputForm';

export function DailyForm() {
  return <DailyInputForm />;
}