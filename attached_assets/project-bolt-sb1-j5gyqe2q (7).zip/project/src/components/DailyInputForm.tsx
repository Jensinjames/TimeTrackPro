import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import DatePicker from 'react-datepicker';
import { Calendar, Clock, Save, Loader2, AlertCircle } from 'lucide-react';
import { useCategoryStore } from '../lib/categoryStore';
import { cn } from '../lib/utils';
import type { CategoryWithPreferences } from '../lib/types';

interface SubcategoryInput {
  id: string;
  name: string;
  duration: number;
  target: number;
}

interface CategoryInput {
  id: string;
  name: string;
  subcategories: SubcategoryInput[];
  notes: string;
}

export function DailyInputForm() {
  const { categories, addMetric, isLoading, error } = useCategoryStore();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [formError, setFormError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [categoryInputs, setCategoryInputs] = useState<CategoryInput[]>([]);
  const [isSaving, setIsSaving] = useState(false);

  // Initialize form data when categories are loaded
  useEffect(() => {
    if (categories.length > 0) {
      const initialInputs = categories.map(category => ({
        id: category.id,
        name: category.name,
        subcategories: category.children?.map(sub => ({
          id: sub.id,
          name: sub.name,
          duration: 0,
          target: sub.preferences?.threshold_warning || 0,
        })) || [],
        notes: '',
      }));
      setCategoryInputs(initialInputs);
    }
  }, [categories]);

  const handleDurationChange = (
    categoryIndex: number,
    subcategoryIndex: number,
    value: number
  ) => {
    const newInputs = [...categoryInputs];
    newInputs[categoryIndex].subcategories[subcategoryIndex].duration = Math.max(0, value);
    setCategoryInputs(newInputs);
  };

  const handleNotesChange = (categoryIndex: number, value: string) => {
    const newInputs = [...categoryInputs];
    newInputs[categoryIndex].notes = value;
    setCategoryInputs(newInputs);
  };

  const calculateProgress = (duration: number, target: number) => {
    return target > 0 ? Math.min((duration / target) * 100, 100) : 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSuccessMessage(null);
    setIsSaving(true);

    try {
      // Validate inputs
      const hasInvalidInputs = categoryInputs.some(category =>
        category.subcategories.some(sub => sub.duration < 0)
      );

      if (hasInvalidInputs) {
        throw new Error('Duration values cannot be negative');
      }

      // Submit metrics for each category
      await Promise.all(
        categoryInputs.map(async (category) => {
          const totalDuration = category.subcategories.reduce(
            (sum, sub) => sum + sub.duration,
            0
          );

          await addMetric({
            category_id: category.id,
            date: format(selectedDate, 'yyyy-MM-dd'),
            value: totalDuration,
            notes: category.notes,
            metadata: {
              subcategories: category.subcategories.map(sub => ({
                id: sub.id,
                duration: sub.duration,
              })),
            },
          });
        })
      );

      setSuccessMessage('Daily metrics saved successfully');
      
      // Reset form
      const resetInputs = categoryInputs.map(category => ({
        ...category,
        subcategories: category.subcategories.map(sub => ({
          ...sub,
          duration: 0,
        })),
        notes: '',
      }));
      setCategoryInputs(resetInputs);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to save metrics');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-lg">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Daily Input</h2>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <DatePicker
              selected={selectedDate}
              onChange={(date: Date) => setSelectedDate(date)}
              maxDate={new Date()}
              className={cn(
                "pl-10 pr-4 py-2 border border-gray-300 rounded-lg",
                "focus:outline-none focus:ring-2 focus:ring-blue-500"
              )}
              dateFormat="MMM d, yyyy"
            />
          </div>
        </div>

        {formError && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start">
            <AlertCircle className="w-5 h-5 text-red-500 mt-0.5 mr-3" />
            <p className="text-sm text-red-700">{formError}</p>
          </div>
        )}

        {successMessage && (
          <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4">
            <p className="text-sm text-green-700">{successMessage}</p>
          </div>
        )}

        <div className="space-y-8">
          {categoryInputs.map((category, categoryIndex) => (
            <div key={category.id} className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">{category.name}</h3>
              
              <div className="space-y-4">
                {category.subcategories.map((subcategory, subcategoryIndex) => (
                  <div key={subcategory.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium text-gray-700">
                        {subcategory.name}
                      </label>
                      <span className="text-sm text-gray-500">
                        Target: {subcategory.target} minutes
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="relative flex-1">
                        <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="number"
                          value={subcategory.duration}
                          onChange={(e) => handleDurationChange(
                            categoryIndex,
                            subcategoryIndex,
                            Number(e.target.value)
                          )}
                          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Duration in minutes"
                          min="0"
                        />
                      </div>
                      
                      <div className="w-24 text-right">
                        <span className="text-sm font-medium text-gray-900">
                          {calculateProgress(subcategory.duration, subcategory.target)}%
                        </span>
                      </div>
                    </div>

                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-500 transition-all duration-300"
                        style={{
                          width: `${calculateProgress(subcategory.duration, subcategory.target)}%`,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Notes
                </label>
                <textarea
                  value={category.notes}
                  onChange={(e) => handleNotesChange(categoryIndex, e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={2}
                  placeholder="Add any notes or comments..."
                />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className={cn(
              "inline-flex items-center gap-2 px-6 py-2 rounded-lg",
              "bg-blue-600 text-white hover:bg-blue-700",
              "transition-colors duration-200",
              "disabled:opacity-50 disabled:cursor-not-allowed"
            )}
          >
            {isSaving ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-5 h-5" />
                Save Metrics
              </>
            )}
          </button>
        </div>
      </div>
    </form>
  );
}