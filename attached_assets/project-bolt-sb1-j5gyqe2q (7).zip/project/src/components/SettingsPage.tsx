import React, { useState, useEffect } from 'react';
import { Plus, Trash2, ChevronDown, ChevronRight, Clock, Percent, Check } from 'lucide-react';
import { useCategoryStore } from '../lib/categoryStore';
import { cn } from '../lib/utils';
import type { CategoryDefinition } from '../lib/types';

interface NewSubcategory {
  name: string;
  unit: 'hours' | 'boolean' | 'percentage';
  timeframe: 'daily' | 'weekly';
  formula?: string;
}

interface DefaultCategory {
  id: string;
  name: string;
}

const DEFAULT_CATEGORIES: DefaultCategory[] = [
  { id: '1f8f7b6f-f8c3-4b9b-b1e9-8c2b6e7d8e9f', name: 'Work' },
  { id: '2a9f8b7f-f9c4-4c9c-b2e9-9d3b7e8d9f0f', name: 'Life' },
  { id: '3b0f9c8f-f0d5-5d0d-c3f0-0e4c8f9d0f1f', name: 'Faith' },
  { id: '4c1f0d9f-f1e6-6e1e-d4f1-1f5d9f0e1f2f', name: 'Health' }
];

export function SettingsPage() {
  const { categories, addCategory, deleteCategory, isLoading, error, fetchCategories } = useCategoryStore();
  const [expandedCategories, setExpandedCategories] = useState<string[]>([]);
  const [newSubcategory, setNewSubcategory] = useState<NewSubcategory>({
    name: '',
    unit: 'hours',
    timeframe: 'daily',
  });
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  const handleToggleCategory = (categoryId: string) => {
    setExpandedCategories(prev =>
      prev.includes(categoryId)
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleAddSubcategory = async (parentId: string) => {
    setFormError(null);
    
    if (!newSubcategory.name.trim()) {
      setFormError('Category name is required');
      return;
    }

    try {
      await addCategory({
        name: newSubcategory.name,
        type: 'metric',
        unit: newSubcategory.unit,
        time_period: newSubcategory.timeframe,
        formula: newSubcategory.formula,
        parent_id: parentId,
        is_active: true,
      });

      setNewSubcategory({
        name: '',
        unit: 'hours',
        timeframe: 'daily',
      });
      setSelectedCategory(null);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to add category');
    }
  };

  const handleDeleteCategory = async (categoryId: string) => {
    try {
      await deleteCategory(categoryId);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to delete category');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500" />
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Category Settings</h1>
        <p className="mt-1 text-sm text-gray-500">
          Manage your categories and tracking preferences
        </p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}

      <div className="bg-white shadow-lg rounded-lg divide-y divide-gray-200">
        {/* Default Categories */}
        <div className="p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Default Categories</h2>
          <div className="space-y-4">
            {DEFAULT_CATEGORIES.map((category) => (
              <div key={category.id} className="rounded-lg border border-gray-200">
                <div className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleToggleCategory(category.id)}
                      className="p-1 hover:bg-gray-100 rounded-full transition-colors"
                    >
                      {expandedCategories.includes(category.id) ? (
                        <ChevronDown className="w-5 h-5 text-gray-500" />
                      ) : (
                        <ChevronRight className="w-5 h-5 text-gray-500" />
                      )}
                    </button>
                    <span className="font-medium text-gray-900">{category.name}</span>
                  </div>
                  <span className="text-sm text-gray-500">Default Category</span>
                </div>

                {expandedCategories.includes(category.id) && (
                  <div className="border-t border-gray-200 p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-medium text-gray-700">Subcategories</h3>
                      <button
                        onClick={() => setSelectedCategory(category.id)}
                        className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-700"
                      >
                        <Plus className="w-4 h-4" />
                        Add Subcategory
                      </button>
                    </div>

                    {selectedCategory === category.id && (
                      <div className="bg-gray-50 p-4 rounded-lg space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Name
                          </label>
                          <input
                            type="text"
                            value={newSubcategory.name}
                            onChange={(e) => setNewSubcategory(prev => ({ ...prev, name: e.target.value }))}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Enter subcategory name"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Unit
                            </label>
                            <select
                              value={newSubcategory.unit}
                              onChange={(e) => setNewSubcategory(prev => ({
                                ...prev,
                                unit: e.target.value as 'hours' | 'boolean' | 'percentage'
                              }))}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <option value="hours">Hours</option>
                              <option value="boolean">Yes/No</option>
                              <option value="percentage">Percentage</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Timeframe
                            </label>
                            <select
                              value={newSubcategory.timeframe}
                              onChange={(e) => setNewSubcategory(prev => ({
                                ...prev,
                                timeframe: e.target.value as 'daily' | 'weekly'
                              }))}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <option value="daily">Daily</option>
                              <option value="weekly">Weekly</option>
                            </select>
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Formula (optional)
                          </label>
                          <input
                            type="text"
                            value={newSubcategory.formula || ''}
                            onChange={(e) => setNewSubcategory(prev => ({ ...prev, formula: e.target.value }))}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Enter calculation formula"
                          />
                        </div>

                        {formError && (
                          <p className="text-sm text-red-600">{formError}</p>
                        )}

                        <div className="flex justify-end gap-3">
                          <button
                            type="button"
                            onClick={() => setSelectedCategory(null)}
                            className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={() => handleAddSubcategory(category.id)}
                            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                          >
                            <Plus className="w-4 h-4" />
                            Add
                          </button>
                        </div>
                      </div>
                    )}

                    <div className="space-y-2">
                      {categories
                        .filter(cat => cat.parent_id === category.id)
                        .map((subcategory) => (
                          <div
                            key={subcategory.id}
                            className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                          >
                            <div className="flex items-center gap-3">
                              {subcategory.unit === 'hours' && (
                                <Clock className="w-4 h-4 text-gray-400" />
                              )}
                              {subcategory.unit === 'percentage' && (
                                <Percent className="w-4 h-4 text-gray-400" />
                              )}
                              {subcategory.unit === 'boolean' && (
                                <Check className="w-4 h-4 text-gray-400" />
                              )}
                              <span className="text-sm font-medium">{subcategory.name}</span>
                              <span className="text-xs text-gray-500">
                                {subcategory.unit} • {subcategory.time_period}
                              </span>
                            </div>
                            <button
                              onClick={() => handleDeleteCategory(subcategory.id)}
                              className="text-gray-400 hover:text-red-500 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}