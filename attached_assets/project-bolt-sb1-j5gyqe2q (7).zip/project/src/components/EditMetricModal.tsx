import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
import { X, Loader2, Calendar, Plus, Trash2 } from 'lucide-react';
import { cn } from '../lib/utils';
import { useLifeTrackingStore as useStore } from '../lib/store';

interface SubEntry {
  description: string;
  duration: number;
}

interface EditMetricModalProps {
  isOpen: boolean;
  onClose: () => void;
  category: string;
  initialValues: {
    goalHours: number;
    actualHours: number;
  };
}

export function EditMetricModal({ isOpen, onClose, category, initialValues }: EditMetricModalProps) {
  const [formData, setFormData] = useState({
    date: new Date(),
    category,
    goalHours: initialValues.goalHours,
    actualHours: initialValues.actualHours,
    subEntries: [{ description: '', duration: initialValues.actualHours }],
  });
  const [errors, setErrors] = useState<Partial<Record<keyof typeof formData | 'subEntries', string>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { updateMetric, categories } = useStore();

  const defaultCategories = ['Work', 'Health', 'Life', 'Faith'];
  const allCategories = [...defaultCategories, ...(categories?.map(cat => cat.name) || [])];

  if (!isOpen) return null;

  const validateForm = () => {
    const newErrors: Partial<Record<keyof typeof formData | 'subEntries', string>> = {};

    if (!formData.category) {
      newErrors.category = 'Category is required';
    }
    if (formData.goalHours <= 0) {
      newErrors.goalHours = 'Goal hours must be greater than 0';
    }
    if (formData.actualHours < 0) {
      newErrors.actualHours = 'Actual hours cannot be negative';
    }

    const hasEmptySubEntries = formData.subEntries.some(entry => !entry.description.trim());
    if (hasEmptySubEntries) {
      newErrors.subEntries = 'All sub-entries must have a description';
    }

    const hasNegativeDuration = formData.subEntries.some(entry => entry.duration < 0);
    if (hasNegativeDuration) {
      newErrors.subEntries = 'Duration cannot be negative';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubEntryChange = (index: number, field: keyof SubEntry, value: string | number) => {
    const newSubEntries = [...formData.subEntries];
    newSubEntries[index] = {
      ...newSubEntries[index],
      [field]: field === 'duration' ? Number(value) : value,
    };

    // Update actual hours based on sub-entries
    const totalHours = newSubEntries.reduce((sum, entry) => sum + entry.duration, 0);

    setFormData(prev => ({
      ...prev,
      subEntries: newSubEntries,
      actualHours: totalHours,
    }));
  };

  const addSubEntry = () => {
    setFormData(prev => ({
      ...prev,
      subEntries: [...prev.subEntries, { description: '', duration: 0 }],
    }));
  };

  const removeSubEntry = (index: number) => {
    if (formData.subEntries.length === 1) return;
    
    const newSubEntries = formData.subEntries.filter((_, i) => i !== index);
    const totalHours = newSubEntries.reduce((sum, entry) => sum + entry.duration, 0);

    setFormData(prev => ({
      ...prev,
      subEntries: newSubEntries,
      actualHours: totalHours,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      await updateMetric({
        category: formData.category,
        goalHours: formData.goalHours,
        actualHours: formData.actualHours,
      });
      onClose();
    } catch (error) {
      console.error('Error updating metric:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-semibold">Edit {category} Metrics</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
                  <DatePicker
                    selected={formData.date}
                    onChange={(date: Date) => setFormData(prev => ({ ...prev, date }))}
                    className={cn(
                      "w-full pl-10 pr-4 py-2 text-sm text-gray-900",
                      "border border-gray-300 rounded-lg",
                      "focus:outline-none focus:ring-2 focus:ring-blue-500"
                    )}
                    dateFormat="MMM d, yyyy"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select
                  value={formData.category}
                  onChange={e => setFormData(prev => ({ ...prev, category: e.target.value }))}
                  className={cn(
                    "w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500",
                    errors.category ? "border-red-500" : "border-gray-300"
                  )}
                >
                  {allCategories.map(category => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
                {errors.category && (
                  <p className="text-red-500 text-sm mt-1">{errors.category}</p>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Goal Hours
              </label>
              <input
                type="number"
                min="0"
                step="0.5"
                value={formData.goalHours}
                onChange={e => setFormData(prev => ({ ...prev, goalHours: parseFloat(e.target.value) }))}
                className={cn(
                  "w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500",
                  errors.goalHours ? "border-red-500" : "border-gray-300"
                )}
              />
              {errors.goalHours && (
                <p className="text-red-500 text-sm mt-1">{errors.goalHours}</p>
              )}
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="block text-sm font-medium text-gray-700">
                  Time Entries
                </label>
                <button
                  type="button"
                  onClick={addSubEntry}
                  className="text-sm text-blue-600 hover:text-blue-700 flex items-center gap-1"
                >
                  <Plus className="w-4 h-4" />
                  Add Entry
                </button>
              </div>

              {formData.subEntries.map((entry, index) => (
                <div key={index} className="flex gap-4 items-start">
                  <div className="flex-grow">
                    <input
                      type="text"
                      value={entry.description}
                      onChange={e => handleSubEntryChange(index, 'description', e.target.value)}
                      placeholder="Description"
                      className={cn(
                        "w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500",
                        errors.subEntries ? "border-red-500" : "border-gray-300"
                      )}
                    />
                  </div>
                  <div className="w-32">
                    <input
                      type="number"
                      min="0"
                      step="0.5"
                      value={entry.duration}
                      onChange={e => handleSubEntryChange(index, 'duration', e.target.value)}
                      placeholder="Hours"
                      className={cn(
                        "w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500",
                        errors.subEntries ? "border-red-500" : "border-gray-300"
                      )}
                    />
                  </div>
                  {formData.subEntries.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeSubEntry(index)}
                      className="text-gray-400 hover:text-red-500 transition-colors p-2"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}

              {errors.subEntries && (
                <p className="text-red-500 text-sm">{errors.subEntries}</p>
              )}

              <div className="flex justify-between items-center py-2 px-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium text-gray-700">Total Hours:</span>
                <span className="text-sm font-semibold">{formData.actualHours}</span>
              </div>
            </div>

            <div className="flex justify-end gap-4 pt-4 border-t">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors disabled:bg-blue-300 flex items-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Save Changes'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}