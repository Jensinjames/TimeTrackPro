import React from 'react';
import { motion } from 'framer-motion';
import { Plus, Calendar, Activity, Brain, Moon, Heart } from 'lucide-react';
import { DashboardMetrics } from './DashboardMetrics';
import { DashboardCharts } from './DashboardCharts';
import { ValueCard } from './ValueCard';
import { DataEntryModal } from './DataEntryModal';
import { useCategoryStore } from '../lib/categoryStore';
import { useRealtime } from '../lib/realtime';
import { cn } from '../lib/utils';
import { format } from 'date-fns';

const CATEGORY_COLORS = {
  Faith: 'bg-emerald-500',
  Life: 'bg-amber-500',
  Work: 'bg-red-500',
  Health: 'bg-pink-500'
};

export function Dashboard() {
  const { categories, fetchCategories, isLoading } = useCategoryStore();
  const { initialize, disconnect, isConnected, lastUpdated } = useRealtime();
  const [showAddModal, setShowAddModal] = React.useState(false);
  const [selectedDateRange, setSelectedDateRange] = React.useState({
    start: new Date(),
    end: new Date()
  });

  React.useEffect(() => {
    fetchCategories();
    initialize();

    return () => {
      disconnect();
    };
  }, [fetchCategories, initialize, disconnect]);

  const getOverallScore = () => {
    if (!categories.length) return 0;
    return Math.round(
      categories.reduce((acc, cat) => acc + (cat.metrics?.[0]?.score || 0), 0) / categories.length
    );
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="mt-1 text-sm text-gray-500">
            {format(new Date(), 'EEEE, MMMM d, yyyy')}
            {isConnected && (
              <span className="ml-2 text-emerald-600 inline-flex items-center">
                <span className="w-2 h-2 bg-emerald-500 rounded-full mr-1 animate-pulse" />
                Live
              </span>
            )}
          </p>
        </div>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setShowAddModal(true)}
          className={cn(
            "inline-flex items-center gap-2 px-4 py-2 rounded-lg",
            "bg-blue-600 text-white hover:bg-blue-700",
            "shadow-lg shadow-blue-500/20",
            "transition-all duration-200"
          )}
        >
          <Plus className="w-5 h-5" />
          <span>Add Entry</span>
        </motion.button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl shadow-lg p-6"
        >
          <div className="flex items-center gap-4">
            <div className="bg-blue-500 p-3 rounded-lg">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Daily Score</p>
              <h3 className="text-2xl font-bold">{getOverallScore()}%</h3>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl shadow-lg p-6"
        >
          <div className="flex items-center gap-4">
            <div className="bg-purple-500 p-3 rounded-lg">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Focus Time</p>
              <h3 className="text-2xl font-bold">6.5h</h3>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl shadow-lg p-6"
        >
          <div className="flex items-center gap-4">
            <div className="bg-indigo-500 p-3 rounded-lg">
              <Moon className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Sleep Quality</p>
              <h3 className="text-2xl font-bold">85%</h3>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-xl shadow-lg p-6"
        >
          <div className="flex items-center gap-4">
            <div className="bg-emerald-500 p-3 rounded-lg">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Health Index</p>
              <h3 className="text-2xl font-bold">92%</h3>
            </div>
          </div>
        </motion.div>
      </div>

      <DashboardCharts categories={categories} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {categories.map((category) => (
          <motion.div
            key={category.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <ValueCard
              title={category.name}
              icon={Calendar}
              color={CATEGORY_COLORS[category.name as keyof typeof CATEGORY_COLORS] || 'bg-blue-500'}
              reality={{
                description: 'Current metrics and progress',
                metrics: [
                  { 
                    label: 'Progress', 
                    value: category.metrics?.[0]?.value || 0 
                  }
                ]
              }}
              goal={{
                description: 'Target metrics and goals',
                metrics: [
                  { 
                    label: 'Target', 
                    value: category.preferences?.threshold_warning || 100 
                  }
                ]
              }}
              chartData={[
                { name: 'Progress', value: 75 },
                { name: 'Remaining', value: 25 }
              ]}
            />
          </motion.div>
        ))}
      </div>

      <DataEntryModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
      />
    </div>
  );
}