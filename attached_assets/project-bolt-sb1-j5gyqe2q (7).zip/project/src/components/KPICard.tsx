import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface KPICardProps {
  title: string;
  mainMetric: {
    label: string;
    value: string | number;
    target?: string | number;
  };
  secondaryMetrics: Array<{
    label: string;
    value: string | number;
  }>;
  icon: LucideIcon;
  color: string;
}

export function KPICard({ 
  title, 
  mainMetric, 
  secondaryMetrics, 
  icon: Icon, 
  color,
}: KPICardProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <div className="flex items-start gap-4">
        <div className={`${color} p-3 rounded-lg`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-sm font-medium text-gray-600">{title}</h3>
          <p className="text-2xl font-semibold mt-1">{mainMetric.value}</p>
          <p className="text-sm text-gray-500 mt-1">{mainMetric.label}</p>
          <div className="mt-2 space-y-1">
            {secondaryMetrics.map((metric, index) => (
              <div key={index} className="text-sm">
                <span className="text-gray-500">{metric.label}: </span>
                <span className="font-medium">{metric.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}