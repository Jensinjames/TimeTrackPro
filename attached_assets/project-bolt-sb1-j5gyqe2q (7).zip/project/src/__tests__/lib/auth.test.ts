import { describe, it, expect, beforeEach } from 'vitest';
import { useAuth } from '../../lib/auth';

describe('auth store', () => {
  let store: ReturnType<typeof useAuth>;

  beforeEach(() => {
    store = useAuth.getState();
  });

  it('handles sign out', async () => {
    await store.signOut();
    expect(store.user).toBeNull();
    expect(store.error).toBeNull();
  });

  it('handles sign in errors', async () => {
    const response = await store.signIn('invalid@email.com', 'wrongpassword');
    expect(response.error).toBeDefined();
  });

  it('handles initialization', async () => {
    await store.initialize();
    expect(store.isLoading).toBe(false);
  });
});