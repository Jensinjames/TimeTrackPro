import { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './lib/auth';
import { AuthPanel } from './components/AuthPanel';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Sidebar } from './components/Sidebar';
import { Breadcrumbs } from './components/Breadcrumbs';
import { SettingsPage } from './components/SettingsPage';
import { Dashboard } from './components/Dashboard';
import { DailyForm } from './components/DailyForm';
import { TimeEntryManager } from './components/TimeEntryManager';
import { NotFound } from './components/NotFound';

function App() {
  const { initialize } = useAuth();

  useEffect(() => {
    initialize();
  }, [initialize]);

  return (
    <Router>
      <Routes>
        <Route path="/auth/*" element={<AuthPanel />} />
        
        <Route path="*" element={
          <ProtectedRoute>
            <div className="min-h-screen bg-gray-50">
              <Sidebar />
              <div className="lg:pl-64">
                <main className="p-6">
                  <div className="mb-6">
                    <Breadcrumbs />
                  </div>
                  <Routes>
                    <Route index element={<Dashboard />} />
                    <Route path="daily" element={<DailyForm />} />
                    <Route path="entries" element={<TimeEntryManager />} />
                    <Route path="settings" element={<SettingsPage />} />
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </main>
              </div>
            </div>
          </ProtectedRoute>
        }>
          <Route index element={<Dashboard />} />
          <Route path="daily" element={<DailyForm />} />
          <Route path="entries" element={<TimeEntryManager />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;