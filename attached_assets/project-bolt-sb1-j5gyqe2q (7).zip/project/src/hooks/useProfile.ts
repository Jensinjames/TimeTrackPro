// src/hooks/useProfile.ts
import { useEffect } from 'react';
import { useAuth } from '../lib/auth';
import { useLifeTrackingStore } from '../lib/store';
import { supabase } from '../lib/supabase';
import { ensureProfileExists } from '../lib/ensureProfileExists'; // <-- make sure this exists
import type { Profile } from '../lib/types';

export function useProfile() {
  const { user } = useAuth();
  const { profile, isLoading, setProfile, setLoading, error, setError } = useLifeTrackingStore();

  useEffect(() => {
    let isMounted = true;

    async function initializeProfile() {
      if (!user) return;

      setLoading(true);
      setError(null);

      try {
        // 1) Confirm user via Auth
        const {
          data: { user: authUser },
          error: authError,
        } = await supabase.auth.getUser();
        if (authError) throw authError;
        if (!authUser) throw new Error('User not authenticated');

        // 2) Check for existing profile by user_id
        const { data: existingProfile, error: fetchError } = await supabase
          .from<Profile>('profiles')
          .select('*')
          .eq('user_id', authUser.id)
          .maybeSingle();

        if (fetchError) throw fetchError;

        // 3) Create profile if none exists
        if (!existingProfile) {
          await ensureProfileExists(authUser.id);
        }

        // 4) Fetch the (new or existing) profile data
        const { data: freshProfile, error: profileError } = await supabase
          .from<Profile>('profiles')
          .select('*')
          .eq('user_id', authUser.id)
          .single();

        if (profileError) throw profileError;

        if (isMounted) {
          setProfile(freshProfile);
        }
      } catch (err) {
        console.error('Error initializing profile:', err);
        if (isMounted) {
          setError((err as Error).message);
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    }

    initializeProfile();

    return () => {
      isMounted = false;
    };
  }, [user, setLoading, setProfile, setError]);

  return { profile, isLoading, error };
}
