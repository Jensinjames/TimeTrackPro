/*
  # Optimize RLS policies and remove duplicate index
  
  1. Changes
    - Remove duplicate category_definitions index
    - Optimize RLS policies with subqueries
    - Add performance validation
    
  2. Security
    - Maintain same security guarantees
    - Add validation checks
*/

-- Remove duplicate index
DROP INDEX IF EXISTS idx_category_definitions_user;

-- Update category_preferences policy
DROP POLICY IF EXISTS "Users can manage their preferences" ON category_preferences;

CREATE POLICY "Users can manage their preferences"
ON category_preferences
FOR ALL
TO authenticated
USING (
  user_id = (SELECT auth.uid())
)
WITH CHECK (
  user_id = (SELECT auth.uid())
);

-- Update subcategories policy
DROP POLICY IF EXISTS "Users can manage own subcategories" ON subcategories;

CREATE POLICY "Users can manage own subcategories"
ON subcategories
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM categories
    WHERE categories.id = subcategories.category_id
    AND categories.user_id = (SELECT auth.uid())
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM categories
    WHERE categories.id = subcategories.category_id
    AND categories.user_id = (SELECT auth.uid())
  )
);

-- Update time_entries policy
DROP POLICY IF EXISTS "Users can CRUD own time entries" ON time_entries;

CREATE POLICY "Users can CRUD own time entries"
ON time_entries
FOR ALL
TO authenticated
USING (
  user_id = (SELECT auth.uid())
)
WITH CHECK (
  user_id = (SELECT auth.uid())
);

-- Verify policies are working
DO $$
BEGIN
  -- Check category_preferences policy
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_policies 
    WHERE tablename = 'category_preferences' 
    AND policyname = 'Users can manage their preferences'
  ) THEN
    RAISE EXCEPTION 'Category preferences policy not created correctly';
  END IF;

  -- Check subcategories policy
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_policies 
    WHERE tablename = 'subcategories' 
    AND policyname = 'Users can manage own subcategories'
  ) THEN
    RAISE EXCEPTION 'Subcategories policy not created correctly';
  END IF;

  -- Check time_entries policy
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_policies 
    WHERE tablename = 'time_entries' 
    AND policyname = 'Users can CRUD own time entries'
  ) THEN
    RAISE EXCEPTION 'Time entries policy not created correctly';
  END IF;
END;
$$;

-- Add comments for documentation
COMMENT ON POLICY "Users can manage their preferences" ON category_preferences IS 
'Allows users to manage only their own category preferences';

COMMENT ON POLICY "Users can manage own subcategories" ON subcategories IS 
'Allows users to manage subcategories only for categories they own';

COMMENT ON POLICY "Users can CRUD own time entries" ON time_entries IS 
'Allows users to manage only their own time entries';

-- Create function to validate policy performance
CREATE OR REPLACE FUNCTION validate_policy_performance()
RETURNS TABLE (
  policy_name text,
  execution_time interval
)
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  start_time timestamptz;
  end_time timestamptz;
BEGIN
  -- Test category_preferences policy
  start_time := clock_timestamp();
  PERFORM 1 FROM category_preferences WHERE user_id = (SELECT auth.uid()) LIMIT 1;
  end_time := clock_timestamp();
  policy_name := 'Users can manage their preferences';
  execution_time := end_time - start_time;
  RETURN NEXT;
  
  -- Test subcategories policy
  start_time := clock_timestamp();
  PERFORM 1 FROM subcategories 
  WHERE EXISTS (
    SELECT 1 FROM categories 
    WHERE categories.id = subcategories.category_id 
    AND categories.user_id = (SELECT auth.uid())
  ) LIMIT 1;
  end_time := clock_timestamp();
  policy_name := 'Users can manage own subcategories';
  execution_time := end_time - start_time;
  RETURN NEXT;
  
  -- Test time_entries policy
  start_time := clock_timestamp();
  PERFORM 1 FROM time_entries WHERE user_id = (SELECT auth.uid()) LIMIT 1;
  end_time := clock_timestamp();
  policy_name := 'Users can CRUD own time entries';
  execution_time := end_time - start_time;
  RETURN NEXT;
END;
$$;

COMMENT ON FUNCTION validate_policy_performance() IS 
'Validates performance of optimized RLS policies';