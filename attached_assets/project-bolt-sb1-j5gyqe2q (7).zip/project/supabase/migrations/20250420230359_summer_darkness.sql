/*
  # Flexible Categories and Metrics System
  
  1. New Tables
    - `category_definitions`
      - Core category configuration
      - Formula rules and calculation settings
      - Display and grouping options
    
    - `metric_data_points` 
      - Raw metric values
      - Timestamped entries
      - Category association
    
    - `category_preferences`
      - User display preferences
      - UI customization settings
      - Active category selections

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Category definitions table
CREATE TABLE category_definitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  parent_id uuid REFERENCES category_definitions(id),
  type text NOT NULL,
  unit text NOT NULL,
  formula text,
  time_period text NOT NULL DEFAULT 'daily',
  is_active boolean DEFAULT true,
  display_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  -- Validation constraints
  CONSTRAINT valid_type CHECK (type IN ('metric', 'group', 'calculated')),
  CONSTRAINT valid_unit CHECK (unit IN ('minutes', 'hours', 'percentage', 'boolean', 'number')),
  CONSTRAINT valid_time_period CHECK (time_period IN ('daily', 'weekly')),
  CONSTRAINT prevent_self_reference CHECK (id != parent_id)
);

-- Raw metric data points
CREATE TABLE metric_data_points (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES category_definitions(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  value numeric NOT NULL,
  date date NOT NULL DEFAULT CURRENT_DATE,
  notes text,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- User category preferences
CREATE TABLE category_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  category_id uuid REFERENCES category_definitions(id) ON DELETE CASCADE,
  is_visible boolean DEFAULT true,
  display_type text DEFAULT 'card',
  custom_color text,
  weight numeric DEFAULT 1.0,
  threshold_warning numeric DEFAULT 0.7,
  threshold_critical numeric DEFAULT 0.4,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  -- Validation constraints
  CONSTRAINT valid_display_type CHECK (display_type IN ('card', 'chart', 'progress')),
  CONSTRAINT valid_weight CHECK (weight BETWEEN 0 AND 10),
  CONSTRAINT valid_thresholds CHECK (threshold_critical < threshold_warning)
);

-- Enable RLS
ALTER TABLE category_definitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE metric_data_points ENABLE ROW LEVEL SECURITY;
ALTER TABLE category_preferences ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can manage their categories"
  ON category_definitions
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can manage their metrics"
  ON metric_data_points
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can manage their preferences"
  ON category_preferences
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes
CREATE INDEX idx_category_definitions_user ON category_definitions(user_id);
CREATE INDEX idx_category_definitions_parent ON category_definitions(parent_id);
CREATE INDEX idx_metric_data_points_category ON metric_data_points(category_id);
CREATE INDEX idx_metric_data_points_user_date ON metric_data_points(user_id, date);
CREATE INDEX idx_category_preferences_user ON category_preferences(user_id);
CREATE INDEX idx_category_preferences_category ON category_preferences(category_id);

-- Update function for timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_category_definitions_updated_at
  BEFORE UPDATE ON category_definitions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_category_preferences_updated_at
  BEFORE UPDATE ON category_preferences
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();