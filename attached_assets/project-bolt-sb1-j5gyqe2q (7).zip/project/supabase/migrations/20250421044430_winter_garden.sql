/*
  # Optimize RLS Policies Performance
  
  1. Changes
    - Update RLS policies to use subqueries for auth functions
    - Improve query performance by reducing function calls
    - Maintain existing security guarantees
    
  2. Security
    - No changes to security rules
    - Only optimization of existing policies
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can manage own time entries" ON time_entries;
DROP POLICY IF EXISTS "Admins can read audit log" ON audit_log;
DROP POLICY IF EXISTS "Users can manage own entries" ON subcategory_entries;
DROP POLICY IF EXISTS "Users can view own audit logs" ON entry_audit_log;
DROP POLICY IF EXISTS "Users can view own achievements" ON achievements;
DROP POLICY IF EXISTS "Users can manage their own profile" ON profiles;

-- Recreate policies with optimized queries
CREATE POLICY "Users can manage own time entries"
ON time_entries
FOR ALL
TO authenticated
USING (
  user_id = (SELECT auth.uid())
)
WITH CHECK (
  user_id = (SELECT auth.uid())
);

CREATE POLICY "Admins can read audit log"
ON audit_log
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM auth.users
    WHERE users.id = (SELECT auth.uid())
    AND users.email LIKE '%@company.com'
  )
);

CREATE POLICY "Users can manage own entries"
ON subcategory_entries
FOR ALL
TO authenticated
USING (
  user_id = (SELECT auth.uid())
)
WITH CHECK (
  user_id = (SELECT auth.uid())
);

CREATE POLICY "Users can view own audit logs"
ON entry_audit_log
FOR SELECT
TO authenticated
USING (
  changed_by = (SELECT auth.uid())
);

CREATE POLICY "Users can view own achievements"
ON achievements
FOR SELECT
TO authenticated
USING (
  user_id = (SELECT auth.uid())
);

CREATE POLICY "Users can manage their own profile"
ON profiles
FOR ALL
TO authenticated
USING (
  id = (SELECT auth.uid())
)
WITH CHECK (
  id = (SELECT auth.uid())
);

-- Add indexes to support the policies
CREATE INDEX IF NOT EXISTS idx_time_entries_user_lookup 
ON time_entries(user_id);

CREATE INDEX IF NOT EXISTS idx_subcategory_entries_user_lookup 
ON subcategory_entries(user_id);

CREATE INDEX IF NOT EXISTS idx_entry_audit_log_user_lookup 
ON entry_audit_log(changed_by);

CREATE INDEX IF NOT EXISTS idx_achievements_user_lookup 
ON achievements(user_id);

-- Add comments
COMMENT ON POLICY "Users can manage own time entries" ON time_entries IS 
'Allows users to manage only their own time entries. Optimized with subquery.';

COMMENT ON POLICY "Admins can read audit log" ON audit_log IS 
'Allows company admins to read audit logs. Optimized with subquery.';

COMMENT ON POLICY "Users can manage own entries" ON subcategory_entries IS 
'Allows users to manage only their own entries. Optimized with subquery.';

COMMENT ON POLICY "Users can view own audit logs" ON entry_audit_log IS 
'Allows users to view only their own audit logs. Optimized with subquery.';

COMMENT ON POLICY "Users can view own achievements" ON achievements IS 
'Allows users to view only their own achievements. Optimized with subquery.';

COMMENT ON POLICY "Users can manage their own profile" ON profiles IS 
'Allows users to manage only their own profile. Optimized with subquery.';