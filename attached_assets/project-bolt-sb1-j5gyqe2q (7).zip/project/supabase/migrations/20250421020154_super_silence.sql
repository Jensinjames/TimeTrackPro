/*
  # Integrate Value System Structure
  
  1. Changes
    - Add new columns to metric_data_points table
    - Add new columns to category_definitions table
    - Update constraints and validation
    
  2. Security
    - Maintain existing RLS policies
    - Add validation for new fields
*/

-- Add new columns to metric_data_points
ALTER TABLE metric_data_points
ADD COLUMN actual_value numeric NOT NULL DEFAULT 0,
ADD COLUMN target_value numeric NOT NULL DEFAULT 0,
ADD COLUMN target_unit text NOT NULL DEFAULT 'hours',
ADD COLUMN score numeric GENERATED ALWAYS AS (
  LEAST((actual_value / NULLIF(target_value, 0)) * 100, 100)
) STORED,
ADD COLUMN timeframe text NOT NULL DEFAULT 'daily',
ADD CONSTRAINT valid_target_unit CHECK (target_unit IN ('hours', 'boolean', 'percentage')),
ADD CONSTRAINT valid_timeframe CHECK (timeframe IN ('daily', 'weekly')),
ADD CONSTRAINT valid_actual_value CHECK (
  (target_unit = 'hours' AND actual_value >= 0) OR
  (target_unit = 'boolean' AND actual_value IN (0, 1)) OR
  (target_unit = 'percentage' AND actual_value BETWEEN 0 AND 100)
);

-- Add new columns to category_definitions
ALTER TABLE category_definitions
ADD COLUMN target_value numeric DEFAULT 0,
ADD COLUMN target_unit text NOT NULL DEFAULT 'hours',
ADD COLUMN timeframe text NOT NULL DEFAULT 'daily',
ADD CONSTRAINT valid_category_target_unit CHECK (target_unit IN ('hours', 'boolean', 'percentage')),
ADD CONSTRAINT valid_category_timeframe CHECK (timeframe IN ('daily', 'weekly')),
ADD CONSTRAINT valid_target_value CHECK (
  (target_unit = 'hours' AND target_value >= 0) OR
  (target_unit = 'boolean' AND target_value IN (0, 1)) OR
  (target_unit = 'percentage' AND target_value BETWEEN 0 AND 100)
);

-- Create index for performance
CREATE INDEX idx_metric_data_points_score ON metric_data_points(score);

-- Add trigger to validate metric values against category settings
CREATE OR REPLACE FUNCTION validate_metric_against_category()
RETURNS TRIGGER AS $$
DECLARE
  category_target_unit text;
BEGIN
  -- Get category settings
  SELECT target_unit INTO category_target_unit
  FROM category_definitions
  WHERE id = NEW.category_id;
  
  -- Validate unit matches
  IF NEW.target_unit != category_target_unit THEN
    RAISE EXCEPTION 'Metric target unit must match category target unit';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER validate_metric_category_settings
BEFORE INSERT OR UPDATE ON metric_data_points
FOR EACH ROW
EXECUTE FUNCTION validate_metric_against_category();

-- Add comments for documentation
COMMENT ON COLUMN metric_data_points.actual_value IS 'The entered value (hours, % complete, or 0/1)';
COMMENT ON COLUMN metric_data_points.target_value IS 'The goal defined by the user';
COMMENT ON COLUMN metric_data_points.target_unit IS 'Interprets input: hours, boolean, percent';
COMMENT ON COLUMN metric_data_points.score IS 'Percentage toward goal (actual ÷ target), capped at 100%';
COMMENT ON COLUMN metric_data_points.timeframe IS 'Grouping logic for daily, weekly rollups';