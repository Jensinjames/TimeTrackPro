/*
  # Optimize RLS and Function Security

  1. Changes
    - Optimize RLS policies with subselects
    - Enhance function security with explicit search paths
    - Add security definer where needed
    - Implement performance optimizations
    
  2. Security
    - Set explicit search paths
    - Add security barriers
    - Implement proper permission checks
*/

-- Drop existing policies to recreate them with optimizations
DROP POLICY IF EXISTS "Users can CRUD own categories" ON public.categories;
DROP POLICY IF EXISTS "Users can manage own metrics" ON public.daily_metrics;
DROP POLICY IF EXISTS "Users can manage own preferences" ON public.category_preferences;

-- Recreate policies with optimized subselects
CREATE POLICY "Users can CRUD own categories"
ON public.categories
FOR ALL
TO authenticated
USING (
  (SELECT auth.uid()) = user_id
)
WITH CHECK (
  (SELECT auth.uid()) = user_id
);

-- Enhance function security with explicit search paths
CREATE OR REPLACE FUNCTION check_category_circular_dependency()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  has_cycle boolean;
BEGIN
  WITH RECURSIVE category_tree AS (
    -- Base case: start with the current category
    SELECT id, parent_id, 1 AS depth
    FROM categories
    WHERE id = NEW.parent_id
    
    UNION ALL
    
    -- Recursive case: join with parent categories
    SELECT c.id, c.parent_id, ct.depth + 1
    FROM categories c
    INNER JOIN category_tree ct ON ct.parent_id = c.id
    WHERE ct.depth < 100  -- Prevent infinite recursion
  )
  SELECT EXISTS (
    SELECT 1 FROM category_tree WHERE id = NEW.id
  ) INTO has_cycle;
  
  IF has_cycle THEN
    RAISE EXCEPTION 'Circular dependency detected in category hierarchy';
  END IF;
  
  RETURN NEW;
END;
$$;

-- Update validate_metric_value function with enhanced security
CREATE OR REPLACE FUNCTION validate_metric_value()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  category_unit text;
  user_id uuid;
BEGIN
  -- Get the category unit and verify ownership
  SELECT c.unit, c.user_id INTO category_unit, user_id
  FROM category_definitions c
  WHERE c.id = NEW.category_id;

  -- Verify user owns the category
  IF user_id != (SELECT auth.uid()) THEN
    RAISE EXCEPTION 'Access denied: User does not own this category';
  END IF;

  -- Validate based on unit type
  IF category_unit IN ('minutes', 'hours') AND NEW.value < 0 THEN
    RAISE EXCEPTION 'Value cannot be negative for time units';
  END IF;

  IF category_unit = 'percentage' AND (NEW.value < 0 OR NEW.value > 100) THEN
    RAISE EXCEPTION 'Percentage must be between 0 and 100';
  END IF;

  IF category_unit = 'hours' AND NEW.value > 24 THEN
    RAISE EXCEPTION 'Hours cannot exceed 24';
  END IF;

  RETURN NEW;
END;
$$;

-- Update timestamp function with enhanced security
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- Verify user owns the record being updated
  IF TG_TABLE_NAME = 'category_definitions' AND 
     NEW.user_id != (SELECT auth.uid()) THEN
    RAISE EXCEPTION 'Access denied: User does not own this record';
  END IF;

  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Recreate optimized indexes
DROP INDEX IF EXISTS idx_category_definitions_user;
CREATE INDEX idx_category_definitions_user 
ON category_definitions(user_id);

DROP INDEX IF EXISTS idx_metric_data_points_composite;
CREATE INDEX idx_metric_data_points_composite 
ON metric_data_points(user_id, category_id, date, value);

-- Add comments for documentation
COMMENT ON FUNCTION check_category_circular_dependency() IS 
'Prevents circular dependencies in category hierarchy with enhanced security';

COMMENT ON FUNCTION validate_metric_value() IS 
'Validates metric values based on category type with ownership verification';

COMMENT ON FUNCTION update_updated_at_column() IS 
'Updates timestamp columns with user ownership verification';

-- Verify RLS is enabled on all tables
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_tables 
    WHERE schemaname = 'public' 
    AND tablename = 'categories' 
    AND rowsecurity = true
  ) THEN
    RAISE EXCEPTION 'RLS not enabled on categories table';
  END IF;
END;
$$;

-- Create function to validate RLS implementation
CREATE OR REPLACE FUNCTION validate_rls_implementation()
RETURNS boolean
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  result boolean;
BEGIN
  -- Test RLS policies
  WITH test_query AS (
    SELECT EXISTS (
      SELECT 1
      FROM categories
      WHERE user_id != (SELECT auth.uid())
      LIMIT 1
    ) as has_unauthorized_access
  )
  SELECT NOT has_unauthorized_access INTO result
  FROM test_query;

  RETURN result;
END;
$$;

COMMENT ON FUNCTION validate_rls_implementation() IS 
'Validates RLS implementation by checking access controls';