/*
  # Add Gamification Fields
  
  1. Changes
    - Add XP, level, and streak tracking to profiles
    - Add achievement tracking table
    - Add triggers for XP and level calculation
    
  2. Security
    - Enable RLS on new tables
    - Add policies for authenticated users
*/

-- Add gamification fields to profiles
ALTER TABLE profiles
ADD COLUMN xp INTEGER DEFAULT 0,
ADD COLUMN level INTEGER DEFAULT 1,
ADD COLUMN score_streak INTEGER DEFAULT 0,
ADD COLUMN last_activity_date TIMESTAMPTZ;

-- Create achievements table
CREATE TABLE achievements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  awarded_at TIMESTAMPTZ DEFAULT now(),
  type TEXT NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  
  CONSTRAINT valid_achievement_type CHECK (type IN ('level', 'streak', 'milestone'))
);

-- Enable RLS on achievements
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;

-- Create RLS policy for achievements
CREATE POLICY "Users can view own achievements"
ON achievements
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Create function to update XP and level
CREATE OR REPLACE FUNCTION update_user_xp()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  xp_to_award INTEGER;
  new_level INTEGER;
BEGIN
  -- Calculate XP based on score_percent (1 XP per percentage point)
  xp_to_award := GREATEST(0, LEAST(100, NEW.score_percent::INTEGER));
  
  -- Update user XP
  UPDATE profiles
  SET 
    xp = xp + xp_to_award,
    last_activity_date = now()
  WHERE id = NEW.user_id
  RETURNING level INTO new_level;
  
  -- Check if user should level up (every 100 XP)
  UPDATE profiles
  SET level = GREATEST(level, (xp / 100) + 1)
  WHERE id = NEW.user_id;
  
  -- Update streak if score is above 80%
  IF NEW.score_percent >= 80 THEN
    UPDATE profiles
    SET score_streak = CASE
      WHEN last_activity_date >= CURRENT_DATE - INTERVAL '1 day' THEN score_streak + 1
      ELSE 1
    END
    WHERE id = NEW.user_id;
  ELSE
    UPDATE profiles
    SET score_streak = 0
    WHERE id = NEW.user_id;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger for XP updates
CREATE TRIGGER update_xp_on_metrics
AFTER INSERT OR UPDATE ON daily_metrics
FOR EACH ROW
EXECUTE FUNCTION update_user_xp();

-- Create function to award achievements
CREATE OR REPLACE FUNCTION check_and_award_achievements()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- Level achievements
  IF NEW.level >= 10 AND OLD.level < 10 THEN
    INSERT INTO achievements (user_id, name, description, type)
    VALUES (NEW.id, 'Master Tracker', 'Reached level 10', 'level');
  END IF;
  
  -- Streak achievements
  IF NEW.score_streak >= 7 AND OLD.score_streak < 7 THEN
    INSERT INTO achievements (user_id, name, description, type)
    VALUES (NEW.id, 'Consistency King', 'Maintained a 7-day streak', 'streak');
  END IF;
  
  -- XP achievements
  IF NEW.xp >= 1000 AND OLD.xp < 1000 THEN
    INSERT INTO achievements (user_id, name, description, type)
    VALUES (NEW.id, 'XP Warrior', 'Earned 1000 XP', 'milestone');
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger for achievements
CREATE TRIGGER check_achievements
AFTER UPDATE ON profiles
FOR EACH ROW
EXECUTE FUNCTION check_and_award_achievements();

-- Add indexes for performance
CREATE INDEX idx_achievements_user ON achievements(user_id);
CREATE INDEX idx_achievements_type ON achievements(type);

-- Add comments
COMMENT ON COLUMN profiles.xp IS 'Experience points earned through daily activities';
COMMENT ON COLUMN profiles.level IS 'Current user level, increases every 100 XP';
COMMENT ON COLUMN profiles.score_streak IS 'Consecutive days with 80%+ performance';
COMMENT ON COLUMN profiles.last_activity_date IS 'Last date user logged activity';
COMMENT ON TABLE achievements IS 'Stores user achievements and milestones';