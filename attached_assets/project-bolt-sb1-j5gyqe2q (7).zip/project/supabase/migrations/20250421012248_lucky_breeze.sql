/*
  # Optimize profiles and users RLS policies
  
  1. Changes
    - Optimize profiles table RLS policies
    - Optimize users table RLS policy
    - Add performance optimized indexes
    
  2. Security
    - Maintain same security guarantees
    - Replace direct auth calls with subqueries
    - Add validation checks
*/

-- Drop existing profiles policies
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;

-- Create optimized profiles policies
CREATE POLICY "Users can view own profile"
ON profiles
FOR SELECT
TO authenticated
USING (
  id = (SELECT auth.uid())
);

CREATE POLICY "Users can update own profile"
ON profiles
FOR UPDATE
TO authenticated
USING (
  id = (SELECT auth.uid())
)
WITH CHECK (
  id = (SELECT auth.uid())
);

-- Drop existing users policy
DROP POLICY IF EXISTS "Users can read own data" ON users;

-- Create optimized users policy
CREATE POLICY "Users can read own data"
ON users
FOR SELECT
TO authenticated
USING (
  id = (SELECT auth.uid())
);

-- Create optimized indexes for policy evaluation
DROP INDEX IF EXISTS idx_profiles_user_lookup;
CREATE INDEX idx_profiles_user_lookup 
ON profiles(id);

DROP INDEX IF EXISTS idx_users_user_lookup;
CREATE INDEX idx_users_user_lookup 
ON users(id);

-- Add NOT NULL constraints
ALTER TABLE profiles 
ALTER COLUMN id SET NOT NULL;

ALTER TABLE users 
ALTER COLUMN id SET NOT NULL;

-- Verify policies are working
DO $$
BEGIN
  -- Check profiles policies
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_policies 
    WHERE tablename = 'profiles' 
    AND policyname IN ('Users can view own profile', 'Users can update own profile')
  ) THEN
    RAISE EXCEPTION 'Profiles policies not created correctly';
  END IF;

  -- Check users policy
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_policies 
    WHERE tablename = 'users' 
    AND policyname = 'Users can read own data'
  ) THEN
    RAISE EXCEPTION 'Users policy not created correctly';
  END IF;
END;
$$;

-- Add comments for documentation
COMMENT ON POLICY "Users can view own profile" ON profiles IS 
'Allows users to view only their own profile';

COMMENT ON POLICY "Users can update own profile" ON profiles IS 
'Allows users to update only their own profile';

COMMENT ON POLICY "Users can read own data" ON users IS 
'Allows users to read only their own user data';

-- Create function to validate policy performance
CREATE OR REPLACE FUNCTION validate_profile_policy_performance()
RETURNS TABLE (
  policy_name text,
  execution_time interval
)
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  start_time timestamptz;
  end_time timestamptz;
BEGIN
  -- Test profiles SELECT policy
  start_time := clock_timestamp();
  PERFORM 1 FROM profiles WHERE id = (SELECT auth.uid()) LIMIT 1;
  end_time := clock_timestamp();
  policy_name := 'Users can view own profile';
  execution_time := end_time - start_time;
  RETURN NEXT;
  
  -- Test profiles UPDATE policy
  start_time := clock_timestamp();
  PERFORM 1 FROM profiles WHERE id = (SELECT auth.uid()) FOR UPDATE;
  end_time := clock_timestamp();
  policy_name := 'Users can update own profile';
  execution_time := end_time - start_time;
  RETURN NEXT;
  
  -- Test users SELECT policy
  start_time := clock_timestamp();
  PERFORM 1 FROM users WHERE id = (SELECT auth.uid()) LIMIT 1;
  end_time := clock_timestamp();
  policy_name := 'Users can read own data';
  execution_time := end_time - start_time;
  RETURN NEXT;
END;
$$;

COMMENT ON FUNCTION validate_profile_policy_performance() IS 
'Validates performance of profile and user RLS policies';