/*
  # Update subcategories constraints
  
  1. Changes
    - Remove hours, tasks, points options from target_unit
    - Remove weekly and monthly options from timeframe
    - Set default unit to minutes
*/

ALTER TABLE subcategories 
  DROP CONSTRAINT valid_unit,
  DROP CONSTRAINT valid_timeframe;

ALTER TABLE subcategories
  ALTER COLUMN target_unit SET DEFAULT 'minutes',
  ADD CONSTRAINT valid_unit CHECK (target_unit = 'minutes'),
  ADD CONSTRAINT valid_timeframe CHECK (timeframe = 'daily');