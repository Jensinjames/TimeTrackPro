/*
  # Add duration column to daily_metrics table

  1. Changes
    - Add `duration` column to `daily_metrics` table
      - Type: numeric
      - Nullable: true
      - Default: null
      - Constraint: Must be >= 0 when not null

  2. Security
    - Existing RLS policies will automatically apply to the new column
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'daily_metrics' 
    AND column_name = 'duration'
  ) THEN
    ALTER TABLE daily_metrics 
    ADD COLUMN duration numeric NULL;

    -- Add constraint to ensure duration is non-negative when present
    ALTER TABLE daily_metrics 
    ADD CONSTRAINT valid_duration 
    CHECK (duration IS NULL OR duration >= 0);
  END IF;
END $$;