/*
  # Time Entries System
  
  1. New Tables
    - `time_entries`
      - Track activity durations
      - Store weekly goals
      - Link to users
      - Categorize activities
    
  2. Views
    - `weekly_progress`
      - Aggregate weekly metrics
      - Calculate completion percentages
    
  3. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Drop existing table if it exists
DROP TABLE IF EXISTS time_entries CASCADE;

-- Create activity category type if it doesn't exist
DO $$ BEGIN
    CREATE TYPE activity_category AS ENUM ('work', 'health', 'faith', 'sleep');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create time entries table
CREATE TABLE time_entries (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    activity_category activity_category NOT NULL,
    subcategory text NOT NULL,
    description text,
    start_time timestamptz NOT NULL,
    duration_minutes integer NOT NULL CHECK (duration_minutes > 0),
    weekly_goal_minutes integer NOT NULL CHECK (weekly_goal_minutes > 0),
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Create indices for better performance
CREATE INDEX idx_time_entries_user_category 
ON time_entries(user_id, activity_category);

CREATE INDEX idx_time_entries_start_time 
ON time_entries(start_time);

-- Enable RLS
ALTER TABLE time_entries ENABLE ROW LEVEL SECURITY;

-- Create RLS policy
CREATE POLICY "Users can manage own time entries"
ON time_entries
FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Create or replace updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger
CREATE TRIGGER update_time_entries_updated_at
    BEFORE UPDATE ON time_entries
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Create weekly progress view
CREATE OR REPLACE VIEW weekly_progress AS
SELECT 
    user_id,
    activity_category,
    subcategory,
    date_trunc('week', start_time) as week_start,
    SUM(duration_minutes) as total_minutes,
    MAX(weekly_goal_minutes) as weekly_goal,
    LEAST(100, ROUND((SUM(duration_minutes)::float / NULLIF(MAX(weekly_goal_minutes), 0)) * 100)) as completion_percentage
FROM time_entries
GROUP BY 
    user_id,
    activity_category,
    subcategory,
    date_trunc('week', start_time);

-- Add comments
COMMENT ON TABLE time_entries IS 'Stores time tracking entries with weekly goals';
COMMENT ON VIEW weekly_progress IS 'Aggregates weekly progress and goal completion';