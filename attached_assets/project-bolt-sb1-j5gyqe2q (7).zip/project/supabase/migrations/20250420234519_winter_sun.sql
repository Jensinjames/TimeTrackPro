/*
  # Schema Improvements for Time Tracking App

  1. Changes
    - Add unique constraint to prevent duplicate metric data points
    - Add composite index for faster metric queries
    - Add constraint to prevent circular dependencies in categories
    - Add validation for metric values based on category type using triggers
*/

-- Add unique constraint to prevent duplicate metric entries
ALTER TABLE metric_data_points
ADD CONSTRAINT unique_metric_data_point 
UNIQUE (user_id, category_id, date);

-- Add composite index for common metric queries
CREATE INDEX IF NOT EXISTS idx_metric_data_points_composite 
ON metric_data_points(user_id, category_id, date, value);

-- Add constraint to prevent circular dependencies in category hierarchy
CREATE OR REPLACE FUNCTION check_category_circular_dependency()
RETURNS TRIGGER AS $$
DECLARE
  has_cycle boolean;
BEGIN
  WITH RECURSIVE category_tree AS (
    -- Base case: start with the current category
    SELECT id, parent_id, 1 AS depth
    FROM category_definitions
    WHERE id = NEW.parent_id
    
    UNION ALL
    
    -- Recursive case: join with parent categories
    SELECT c.id, c.parent_id, ct.depth + 1
    FROM category_definitions c
    INNER JOIN category_tree ct ON ct.parent_id = c.id
    WHERE ct.depth < 100  -- Prevent infinite recursion
  )
  SELECT EXISTS (
    SELECT 1 FROM category_tree WHERE id = NEW.id
  ) INTO has_cycle;
  
  IF has_cycle THEN
    RAISE EXCEPTION 'Circular dependency detected in category hierarchy';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS check_category_circular_dependency_trigger 
ON category_definitions;

CREATE TRIGGER check_category_circular_dependency_trigger
BEFORE INSERT OR UPDATE OF parent_id ON category_definitions
FOR EACH ROW
EXECUTE FUNCTION check_category_circular_dependency();

-- Create function to validate metric values
CREATE OR REPLACE FUNCTION validate_metric_value()
RETURNS TRIGGER AS $$
DECLARE
  category_unit text;
BEGIN
  -- Get the category unit
  SELECT unit INTO category_unit
  FROM category_definitions
  WHERE id = NEW.category_id;

  -- Validate based on unit type
  IF category_unit IN ('minutes', 'hours') AND NEW.value < 0 THEN
    RAISE EXCEPTION 'Value cannot be negative for time units';
  END IF;

  IF category_unit = 'percentage' AND (NEW.value < 0 OR NEW.value > 100) THEN
    RAISE EXCEPTION 'Percentage must be between 0 and 100';
  END IF;

  IF category_unit = 'hours' AND NEW.value > 24 THEN
    RAISE EXCEPTION 'Hours cannot exceed 24';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS validate_metric_value_trigger 
ON metric_data_points;

CREATE TRIGGER validate_metric_value_trigger
BEFORE INSERT OR UPDATE ON metric_data_points
FOR EACH ROW
EXECUTE FUNCTION validate_metric_value();

-- Add index for category preferences queries
CREATE INDEX IF NOT EXISTS idx_category_preferences_composite
ON category_preferences(user_id, category_id, is_visible);

-- Add constraint to ensure valid color format in preferences
ALTER TABLE category_preferences
ADD CONSTRAINT valid_color_format
CHECK (
  custom_color IS NULL OR  -- Allow null values
  custom_color ~ '^#[0-9A-Fa-f]{6}$'  -- Require valid hex color format
);

COMMENT ON CONSTRAINT valid_color_format ON category_preferences IS 
'Ensures custom colors are in valid hex format (e.g., #FF0000)';

COMMENT ON CONSTRAINT unique_metric_data_point ON metric_data_points IS 
'Prevents duplicate metric entries for the same user, category, and date';