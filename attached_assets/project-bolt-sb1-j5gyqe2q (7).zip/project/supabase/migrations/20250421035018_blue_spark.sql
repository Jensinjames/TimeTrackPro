/*
  # Life Tracking System Schema Updates
  
  1. Changes
    - Add daily prompt time to profiles
    - Add sleep quality and daily score columns
    - Add auto-population and summary functions
    - Calculate daily score via trigger
    
  2. Security
    - Maintain RLS policies
    - Add validation triggers
*/

-- Add daily prompt time to profiles
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS daily_prompt_time text;

-- Add new metrics columns to daily_metrics
ALTER TABLE daily_metrics
ADD COLUMN IF NOT EXISTS sleep_quality numeric CHECK (sleep_quality BETWEEN 0 AND 100),
ADD COLUMN IF NOT EXISTS daily_score numeric;

-- Create function to calculate daily score
CREATE OR REPLACE FUNCTION calculate_daily_score()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  category_score numeric;
BEGIN
  -- Calculate category average score
  SELECT COALESCE(AVG(
    CASE 
      WHEN value > target_value THEN 100
      ELSE (value / NULLIF(target_value, 0)) * 100
    END
  ), 0)
  INTO category_score
  FROM metric_data_points mdp
  WHERE mdp.user_id = NEW.user_id
  AND mdp.date = NEW.date;

  -- Calculate weighted score
  NEW.daily_score := ROUND(
    (COALESCE(NEW.motivation_level, 0) * 0.2) +
    (COALESCE(NEW.health_balance, 0) * 0.2) +
    (COALESCE(NEW.sleep_quality, 0) * 0.2) +
    (category_score * 0.4)
  );

  RETURN NEW;
END;
$$;

-- Create trigger for daily score calculation
DROP TRIGGER IF EXISTS calculate_daily_score_trigger ON daily_metrics;
CREATE TRIGGER calculate_daily_score_trigger
  BEFORE INSERT OR UPDATE ON daily_metrics
  FOR EACH ROW
  EXECUTE FUNCTION calculate_daily_score();

-- Create function to auto-populate metrics
CREATE OR REPLACE FUNCTION auto_populate_metrics(
  user_id uuid,
  target_date date
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  previous_metrics jsonb;
BEGIN
  -- Get the most recent metrics for this user
  SELECT jsonb_build_object(
    'motivation_level', AVG(motivation_level),
    'health_balance', AVG(health_balance),
    'sleep_quality', AVG(sleep_quality)
  )
  INTO previous_metrics
  FROM daily_metrics
  WHERE daily_metrics.user_id = auto_populate_metrics.user_id
  AND date >= (target_date - interval '7 days')
  AND date < target_date;

  RETURN previous_metrics;
END;
$$;

-- Create function to generate weekly summary
CREATE OR REPLACE FUNCTION generate_weekly_summary(
  user_id uuid,
  week_start date
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  summary jsonb;
BEGIN
  WITH weekly_stats AS (
    SELECT
      ROUND(AVG(daily_score)) as avg_score,
      ROUND(AVG(motivation_level)) as avg_motivation,
      ROUND(AVG(health_balance)) as avg_health,
      ROUND(AVG(sleep_quality)) as avg_sleep,
      COUNT(*) FILTER (WHERE daily_score >= 80) as high_score_days
    FROM daily_metrics
    WHERE daily_metrics.user_id = generate_weekly_summary.user_id
    AND date >= week_start
    AND date < (week_start + interval '7 days')
  )
  SELECT jsonb_build_object(
    'avg_score', avg_score,
    'avg_motivation', avg_motivation,
    'avg_health', avg_health,
    'avg_sleep', avg_sleep,
    'high_score_days', high_score_days,
    'needs_improvement', (
      SELECT jsonb_agg(category)
      FROM daily_metrics
      WHERE user_id = generate_weekly_summary.user_id
      AND date >= week_start
      AND date < (week_start + interval '7 days')
      AND daily_score < 70
      GROUP BY category
    )
  )
  INTO summary
  FROM weekly_stats;

  RETURN summary;
END;
$$;

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_daily_metrics_user_date 
ON daily_metrics(user_id, date);

CREATE INDEX IF NOT EXISTS idx_daily_metrics_score 
ON daily_metrics(daily_score);

-- Add comments
COMMENT ON COLUMN profiles.daily_prompt_time IS 
'User preferred time for daily logging prompts (24h format)';

COMMENT ON COLUMN daily_metrics.daily_score IS 
'Weighted score calculated from motivation, health, sleep, and category averages';

COMMENT ON FUNCTION auto_populate_metrics IS 
'Suggests metric values based on user historical data';

COMMENT ON FUNCTION generate_weekly_summary IS 
'Generates detailed weekly performance summary with insights';

COMMENT ON FUNCTION calculate_daily_score IS 
'Calculates daily score based on metrics and category averages';