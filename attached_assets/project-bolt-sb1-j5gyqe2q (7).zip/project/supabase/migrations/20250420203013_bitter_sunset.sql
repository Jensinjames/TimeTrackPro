/*
  # Add subcategories support
  
  1. Changes
    - Add subcategories table with:
      - id (uuid, primary key)
      - category_id (uuid, foreign key to categories)
      - name (text)
      - target_value (numeric)
      - target_unit (text)
      - timeframe (text)
      - created_at (timestamp)
      
  2. Security
    - Enable RLS on subcategories table
    - Add policy for authenticated users to manage their subcategories
*/

CREATE TABLE IF NOT EXISTS subcategories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES categories(id) ON DELETE CASCADE,
  name text NOT NULL,
  target_value numeric DEFAULT 0,
  target_unit text DEFAULT 'hours',
  timeframe text DEFAULT 'daily',
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_timeframe CHECK (timeframe IN ('daily', 'weekly', 'monthly')),
  CONSTRAINT valid_unit CHECK (target_unit IN ('hours', 'tasks', 'points'))
);

ALTER TABLE subcategories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own subcategories" ON subcategories
  USING (
    EXISTS (
      SELECT 1 FROM categories
      WHERE categories.id = subcategories.category_id
      AND categories.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM categories
      WHERE categories.id = subcategories.category_id
      AND categories.user_id = auth.uid()
    )
  );

-- Create index for better performance
CREATE INDEX idx_subcategories_category ON subcategories(category_id);