/*
  # Comprehensive Security Implementation for daily_metrics
  
  1. Changes
    - Enable RLS
    - Add comprehensive RLS policies
    - Add data validation constraints
    - Add security indexes
    - Add audit logging
    
  2. Security
    - Restrict access to authenticated users only
    - Ensure users can only access their own data
    - Add data validation
*/

-- Enable RLS if not already enabled
ALTER TABLE daily_metrics ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Users can manage own metrics" ON daily_metrics;

-- Create comprehensive RLS policy
CREATE POLICY "manage_daily_metrics"
ON daily_metrics
FOR ALL
TO authenticated
USING (
  user_id = (SELECT auth.uid())
)
WITH CHECK (
  user_id = (SELECT auth.uid())
);

-- Add NOT NULL constraints for critical fields
ALTER TABLE daily_metrics
ALTER COLUMN user_id SET NOT NULL,
ALTER COLUMN date SET NOT NULL,
ALTER COLUMN category SET NOT NULL;

-- Add data validation constraints
ALTER TABLE daily_metrics
ADD CONSTRAINT valid_sleep_duration 
  CHECK (sleep_duration >= 0 AND sleep_duration <= 24),
ADD CONSTRAINT valid_health_balance
  CHECK (health_balance >= 0 AND health_balance <= 100),
ADD CONSTRAINT valid_motivation_level
  CHECK (motivation_level >= 0 AND motivation_level <= 100);

-- Add unique constraint to prevent duplicate entries
ALTER TABLE daily_metrics
ADD CONSTRAINT unique_daily_metric_entry 
UNIQUE (user_id, date, category);

-- Create indexes for policy evaluation and common queries
DROP INDEX IF EXISTS idx_daily_metrics_user_lookup;
CREATE INDEX idx_daily_metrics_user_lookup 
ON daily_metrics(user_id);

DROP INDEX IF EXISTS idx_daily_metrics_composite;
CREATE INDEX idx_daily_metrics_composite 
ON daily_metrics(user_id, date, category);

-- Create audit logging function
CREATE OR REPLACE FUNCTION log_daily_metrics_changes()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    INSERT INTO audit_log (
      table_name,
      operation,
      record_id,
      old_data,
      changed_by
    ) VALUES (
      'daily_metrics',
      'DELETE',
      OLD.id,
      row_to_json(OLD),
      (SELECT auth.uid())
    );
    RETURN OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    INSERT INTO audit_log (
      table_name,
      operation,
      record_id,
      old_data,
      new_data,
      changed_by
    ) VALUES (
      'daily_metrics',
      'UPDATE',
      NEW.id,
      row_to_json(OLD),
      row_to_json(NEW),
      (SELECT auth.uid())
    );
    RETURN NEW;
  ELSIF TG_OP = 'INSERT' THEN
    INSERT INTO audit_log (
      table_name,
      operation,
      record_id,
      new_data,
      changed_by
    ) VALUES (
      'daily_metrics',
      'INSERT',
      NEW.id,
      row_to_json(NEW),
      (SELECT auth.uid())
    );
    RETURN NEW;
  END IF;
  RETURN NULL;
END;
$$;

-- Create audit log table if it doesn't exist
CREATE TABLE IF NOT EXISTS audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  table_name text NOT NULL,
  operation text NOT NULL,
  record_id uuid NOT NULL,
  old_data jsonb,
  new_data jsonb,
  changed_by uuid NOT NULL,
  changed_at timestamptz DEFAULT now()
);

-- Enable RLS on audit log
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;

-- Create audit log policy
CREATE POLICY "Admins can read audit log"
ON audit_log
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM auth.users
    WHERE auth.users.id = auth.uid()
    AND auth.users.email LIKE '%@company.com'
  )
);

-- Create triggers for audit logging
DROP TRIGGER IF EXISTS daily_metrics_audit_trigger ON daily_metrics;

CREATE TRIGGER daily_metrics_audit_trigger
AFTER INSERT OR UPDATE OR DELETE ON daily_metrics
FOR EACH ROW EXECUTE FUNCTION log_daily_metrics_changes();

-- Verify security implementation
DO $$
BEGIN
  -- Check RLS is enabled
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_tables 
    WHERE schemaname = 'public' 
    AND tablename = 'daily_metrics' 
    AND rowsecurity = true
  ) THEN
    RAISE EXCEPTION 'RLS not enabled on daily_metrics';
  END IF;

  -- Check policy exists
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_policies 
    WHERE tablename = 'daily_metrics' 
    AND policyname = 'manage_daily_metrics'
  ) THEN
    RAISE EXCEPTION 'Policy not created correctly';
  END IF;

  -- Check constraints exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE table_name = 'daily_metrics' 
    AND constraint_name = 'unique_daily_metric_entry'
  ) THEN
    RAISE EXCEPTION 'Constraints not created correctly';
  END IF;
END;
$$;

-- Add documentation
COMMENT ON TABLE daily_metrics IS 
'Stores daily metrics with comprehensive security controls';

COMMENT ON POLICY manage_daily_metrics ON daily_metrics IS 
'Allows users to manage only their own daily metrics';

COMMENT ON TRIGGER daily_metrics_audit_trigger ON daily_metrics IS 
'Logs all changes to daily metrics for audit purposes';