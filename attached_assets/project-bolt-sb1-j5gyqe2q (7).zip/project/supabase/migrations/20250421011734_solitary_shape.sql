/*
  # Optimize category_definitions RLS policies
  
  1. Changes
    - Remove duplicate RLS policies
    - Consolidate into a single optimized policy
    - Add optimized index for policy evaluation
    
  2. Security
    - Maintain same security guarantees
    - Optimize policy expressions
    - Add validation checks
*/

-- Drop existing duplicate policies
DROP POLICY IF EXISTS "Users can manage own categories" ON category_definitions;
DROP POLICY IF EXISTS "Users can manage their categories" ON category_definitions;

-- Create single optimized policy
CREATE POLICY "manage_own_categories"
ON category_definitions
FOR ALL
TO authenticated
USING (
  user_id = (SELECT auth.uid())
)
WITH CHECK (
  user_id = (SELECT auth.uid())
);

-- Create optimized index for policy evaluation
DROP INDEX IF EXISTS idx_category_definitions_user_lookup;
CREATE INDEX idx_category_definitions_user_lookup 
ON category_definitions(user_id);

-- Add constraint to ensure user_id is never null
ALTER TABLE category_definitions 
ALTER COLUMN user_id SET NOT NULL;

-- Verify policy is working
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_policies 
    WHERE tablename = 'category_definitions' 
    AND policyname = 'manage_own_categories'
  ) THEN
    RAISE EXCEPTION 'Policy not created correctly';
  END IF;
END;
$$;

-- Add composite index for common queries
CREATE INDEX idx_category_definitions_composite
ON category_definitions(user_id, type, is_active);

COMMENT ON POLICY manage_own_categories ON category_definitions IS 
'Allows users to manage only their own category definitions';