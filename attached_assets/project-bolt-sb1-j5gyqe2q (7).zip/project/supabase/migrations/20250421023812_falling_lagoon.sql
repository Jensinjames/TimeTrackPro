/*
  # Time Entry Processing Pipeline
  
  1. New Tables
    - `subcategory_entries`
      - Track individual time entries
      - Link to subcategories and users
      - Store granular time data
    
    - `entry_audit_log`
      - Track changes to entries
      - Maintain data lineage
      - Support troubleshooting
  
  2. Functions
    - Aggregation function for metrics calculation
    - Trigger functions for automated processing
    
  3. Security
    - RLS policies for data access
    - Validation constraints
    - Referential integrity
*/

-- Create subcategory_entries table
CREATE TABLE subcategory_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  subcategory_id uuid REFERENCES subcategories(id) ON DELETE CASCADE NOT NULL,
  description text NOT NULL,
  value numeric NOT NULL,
  entry_date date NOT NULL DEFAULT CURRENT_DATE,
  start_time timestamptz NOT NULL DEFAULT now(),
  end_time timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  -- Validation constraints
  CONSTRAINT valid_entry_value CHECK (value >= 0),
  CONSTRAINT valid_time_range CHECK (end_time IS NULL OR end_time > start_time)
);

-- Create entry audit log
CREATE TABLE entry_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_id uuid REFERENCES subcategory_entries(id) ON DELETE CASCADE,
  operation text NOT NULL,
  old_data jsonb,
  new_data jsonb,
  changed_by uuid REFERENCES auth.users(id),
  changed_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE subcategory_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE entry_audit_log ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can manage own entries"
ON subcategory_entries
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can view own audit logs"
ON entry_audit_log
FOR SELECT
TO authenticated
USING (changed_by = auth.uid());

-- Create function to aggregate metrics
CREATE OR REPLACE FUNCTION aggregate_daily_metrics(
  start_date date,
  end_date date,
  target_user_id uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  category_rec RECORD;
  total_value numeric;
  category_id uuid;
BEGIN
  -- Process each category
  FOR category_rec IN (
    SELECT DISTINCT c.id, c.name
    FROM categories c
    JOIN subcategories s ON s.category_id = c.id
    JOIN subcategory_entries e ON e.subcategory_id = s.id
    WHERE e.user_id = target_user_id
    AND e.entry_date BETWEEN start_date AND end_date
  ) LOOP
    -- Calculate total value for category
    SELECT COALESCE(SUM(e.value), 0) INTO total_value
    FROM subcategory_entries e
    JOIN subcategories s ON s.id = e.subcategory_id
    WHERE s.category_id = category_rec.id
    AND e.user_id = target_user_id
    AND e.entry_date BETWEEN start_date AND end_date;

    -- Update or insert daily metrics
    INSERT INTO daily_metrics (
      user_id,
      date,
      category,
      current_reality,
      goal_setting,
      sleep_duration,
      health_balance,
      motivation_level
    )
    VALUES (
      target_user_id,
      start_date,
      category_rec.name,
      total_value::text,
      '0', -- Default goal
      0,   -- Default sleep
      0,   -- Default health
      0    -- Default motivation
    )
    ON CONFLICT (user_id, date, category)
    DO UPDATE SET
      current_reality = EXCLUDED.current_reality,
      updated_at = now();
  END LOOP;
END;
$$;

-- Create trigger function for entry changes
CREATE OR REPLACE FUNCTION process_entry_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Log the change
  IF TG_OP = 'DELETE' THEN
    INSERT INTO entry_audit_log (
      entry_id,
      operation,
      old_data,
      changed_by
    ) VALUES (
      OLD.id,
      TG_OP,
      row_to_json(OLD),
      auth.uid()
    );
  ELSE
    INSERT INTO entry_audit_log (
      entry_id,
      operation,
      old_data,
      new_data,
      changed_by
    ) VALUES (
      COALESCE(NEW.id, OLD.id),
      TG_OP,
      CASE WHEN TG_OP = 'UPDATE' THEN row_to_json(OLD) ELSE NULL END,
      CASE WHEN TG_OP IN ('INSERT', 'UPDATE') THEN row_to_json(NEW) ELSE NULL END,
      auth.uid()
    );
  END IF;

  -- Trigger metrics recalculation
  IF TG_OP = 'DELETE' THEN
    PERFORM aggregate_daily_metrics(OLD.entry_date, OLD.entry_date, OLD.user_id);
  ELSE
    PERFORM aggregate_daily_metrics(NEW.entry_date, NEW.entry_date, NEW.user_id);
  END IF;

  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Create triggers
CREATE TRIGGER entry_audit_trigger
AFTER INSERT OR UPDATE OR DELETE ON subcategory_entries
FOR EACH ROW
EXECUTE FUNCTION process_entry_changes();

-- Create indexes for performance
CREATE INDEX idx_entries_user_date ON subcategory_entries(user_id, entry_date);
CREATE INDEX idx_entries_subcategory ON subcategory_entries(subcategory_id);
CREATE INDEX idx_entries_composite ON subcategory_entries(user_id, subcategory_id, entry_date);

-- Add updated_at trigger
CREATE TRIGGER update_entries_updated_at
BEFORE UPDATE ON subcategory_entries
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

COMMENT ON TABLE subcategory_entries IS 'Stores granular time tracking data for each subcategory';
COMMENT ON TABLE entry_audit_log IS 'Maintains audit trail of all entry changes';
COMMENT ON FUNCTION aggregate_daily_metrics IS 'Aggregates subcategory entries into daily metrics';
COMMENT ON FUNCTION process_entry_changes IS 'Handles entry changes and triggers metric updates';