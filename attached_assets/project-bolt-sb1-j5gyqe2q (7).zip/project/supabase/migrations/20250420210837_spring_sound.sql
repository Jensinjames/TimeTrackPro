/*
  # Create default categories

  1. Changes
    - Add function to ensure default categories exist
    - Create default categories if they don't exist
    - Add trigger to maintain default categories

  2. Security
    - Function runs with security definer to bypass RLS
*/

CREATE OR REPLACE FUNCTION ensure_default_categories()
RETURNS trigger
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  default_categories text[] := ARRAY['Faith', 'Life', 'Work', 'Health'];
  category text;
BEGIN
  FOREACH category IN ARRAY default_categories LOOP
    INSERT INTO categories (name, user_id)
    VALUES (category, NEW.id)
    ON CONFLICT (name, user_id) DO NOTHING;
  END LOOP;
  RETURN NEW;
END;
$$;

-- Create a unique constraint to prevent duplicate default categories per user
ALTER TABLE categories ADD CONSTRAINT unique_category_per_user UNIQUE (name, user_id);

-- Create trigger to ensure default categories exist for new users
CREATE TRIGGER ensure_default_categories_trigger
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION ensure_default_categories();

-- Create default categories for existing users
DO $$
DECLARE
  user_record RECORD;
BEGIN
  FOR user_record IN SELECT id FROM profiles LOOP
    PERFORM ensure_default_categories(user_record);
  END LOOP;
END $$;