/*
  # Optimize metric_data_points RLS policies
  
  1. Changes
    - Remove duplicate RLS policies
    - Consolidate into a single optimized policy
    - Add composite index for policy evaluation
    
  2. Security
    - Maintain same security guarantees
    - Optimize policy expressions
    - Add validation checks
*/

-- Drop existing duplicate policies
DROP POLICY IF EXISTS "Users can manage own metrics" ON metric_data_points;
DROP POLICY IF EXISTS "Users can manage their metrics" ON metric_data_points;

-- Create single optimized policy
CREATE POLICY "manage_own_metrics"
ON metric_data_points
FOR ALL
TO authenticated
USING (
  user_id = (SELECT auth.uid())
)
WITH CHECK (
  user_id = (SELECT auth.uid())
);

-- Create optimized index for policy evaluation
DROP INDEX IF EXISTS idx_metric_data_points_user_lookup;
CREATE INDEX idx_metric_data_points_user_lookup 
ON metric_data_points(user_id);

-- Add constraint to ensure user_id is never null
ALTER TABLE metric_data_points 
ALTER COLUMN user_id SET NOT NULL;

-- Verify policy is working
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_policies 
    WHERE tablename = 'metric_data_points' 
    AND policyname = 'manage_own_metrics'
  ) THEN
    RAISE EXCEPTION 'Policy not created correctly';
  END IF;
END;
$$;

COMMENT ON POLICY manage_own_metrics ON metric_data_points IS 
'Allows users to manage only their own metric data points';