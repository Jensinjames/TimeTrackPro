/*
  # Update Category System Schema

  1. Changes
    - Add user preferences and metric tracking tables
    - Update category definitions with additional fields
    - Add RLS policies and indexes
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can manage their categories" ON category_definitions;
DROP POLICY IF EXISTS "Users can manage their preferences" ON category_preferences;
DROP POLICY IF EXISTS "Users can manage their metrics" ON metric_data_points;

-- User-specific category preferences
CREATE TABLE IF NOT EXISTS category_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    category_id UUID REFERENCES category_definitions(id) ON DELETE CASCADE,
    is_visible BOOLEAN DEFAULT true,
    display_type TEXT DEFAULT 'card' CHECK (display_type IN ('card', 'chart', 'progress')),
    custom_color TEXT,
    weight NUMERIC DEFAULT 1.0 CHECK (weight >= 0 AND weight <= 10),
    threshold_warning NUMERIC DEFAULT 0.7,
    threshold_critical NUMERIC DEFAULT 0.4,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT valid_thresholds CHECK (threshold_critical < threshold_warning)
);

-- Metric data points for tracking
CREATE TABLE IF NOT EXISTS metric_data_points (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    category_id UUID REFERENCES category_definitions(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    value NUMERIC NOT NULL,
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    notes TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE category_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE metric_data_points ENABLE ROW LEVEL SECURITY;

-- Create RLS Policies
CREATE POLICY "Users can manage their categories"
    ON category_definitions FOR ALL
    TO authenticated
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can manage their preferences"
    ON category_preferences FOR ALL
    TO authenticated
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can manage their metrics"
    ON metric_data_points FOR ALL
    TO authenticated
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_category_definitions_parent ON category_definitions(parent_id);
CREATE INDEX IF NOT EXISTS idx_category_definitions_user ON category_definitions(user_id);
CREATE INDEX IF NOT EXISTS idx_metric_data_points_category ON metric_data_points(category_id);
CREATE INDEX IF NOT EXISTS idx_metric_data_points_user_date ON metric_data_points(user_id, date);
CREATE INDEX IF NOT EXISTS idx_category_preferences_user ON category_preferences(user_id);
CREATE INDEX IF NOT EXISTS idx_category_preferences_category ON category_preferences(category_id);

-- Create updated_at trigger function if it doesn't exist
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add updated_at triggers
DROP TRIGGER IF EXISTS update_category_definitions_updated_at ON category_definitions;
DROP TRIGGER IF EXISTS update_category_preferences_updated_at ON category_preferences;

CREATE TRIGGER update_category_definitions_updated_at
    BEFORE UPDATE ON category_definitions
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_category_preferences_updated_at
    BEFORE UPDATE ON category_preferences
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();