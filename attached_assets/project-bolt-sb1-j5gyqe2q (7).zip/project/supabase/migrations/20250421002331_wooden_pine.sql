/*
  # Enhance Data Validation and Indexing

  1. Changes
    - Add composite index for common queries
    - Add circular dependency prevention
    - Add metric value validation
    - Add color format validation
    - Optimize RLS policies
    - Remove unused indexes

  2. Security
    - Update RLS policies to use subqueries
    - Add validation triggers
    - Add constraints for data integrity
*/

-- Add composite index for common metric queries
CREATE INDEX IF NOT EXISTS idx_metric_data_points_composite 
ON metric_data_points(user_id, category_id, date, value);

-- Add constraint to prevent circular dependencies in category hierarchy
CREATE OR REPLACE FUNCTION check_category_circular_dependency()
RETURNS TRIGGER AS $$
DECLARE
  has_cycle boolean;
BEGIN
  WITH RECURSIVE category_tree AS (
    -- Base case: start with the current category
    SELECT id, parent_id, 1 AS depth
    FROM category_definitions
    WHERE id = NEW.parent_id
    
    UNION ALL
    
    -- Recursive case: join with parent categories
    SELECT c.id, c.parent_id, ct.depth + 1
    FROM category_definitions c
    INNER JOIN category_tree ct ON ct.parent_id = c.id
    WHERE ct.depth < 100  -- Prevent infinite recursion
  )
  SELECT EXISTS (
    SELECT 1 FROM category_tree WHERE id = NEW.id
  ) INTO has_cycle;
  
  IF has_cycle THEN
    RAISE EXCEPTION 'Circular dependency detected in category hierarchy';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS check_category_circular_dependency_trigger 
ON category_definitions;

CREATE TRIGGER check_category_circular_dependency_trigger
BEFORE INSERT OR UPDATE OF parent_id ON category_definitions
FOR EACH ROW
EXECUTE FUNCTION check_category_circular_dependency();

-- Create function to validate metric values
CREATE OR REPLACE FUNCTION validate_metric_value()
RETURNS TRIGGER AS $$
DECLARE
  category_unit text;
BEGIN
  SELECT unit INTO category_unit
  FROM category_definitions
  WHERE id = NEW.category_id;

  IF category_unit IN ('minutes', 'hours') AND NEW.value < 0 THEN
    RAISE EXCEPTION 'Value cannot be negative for time units';
  END IF;

  IF category_unit = 'percentage' AND (NEW.value < 0 OR NEW.value > 100) THEN
    RAISE EXCEPTION 'Percentage must be between 0 and 100';
  END IF;

  IF category_unit = 'hours' AND NEW.value > 24 THEN
    RAISE EXCEPTION 'Hours cannot exceed 24';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS validate_metric_value_trigger 
ON metric_data_points;

CREATE TRIGGER validate_metric_value_trigger
BEFORE INSERT OR UPDATE ON metric_data_points
FOR EACH ROW
EXECUTE FUNCTION validate_metric_value();

-- Add constraint to ensure valid color format in preferences
DO $$ 
BEGIN
  ALTER TABLE category_preferences
  ADD CONSTRAINT valid_color_format
  CHECK (
    custom_color IS NULL OR  -- Allow null values
    custom_color ~ '^#[0-9A-Fa-f]{6}$'  -- Require valid hex color format
  );
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Update RLS policies to use subqueries
DROP POLICY IF EXISTS "Users can manage own categories" ON category_definitions;
CREATE POLICY "Users can manage own categories" ON category_definitions
FOR ALL TO authenticated
USING ((SELECT auth.uid()) = user_id)
WITH CHECK ((SELECT auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can manage own preferences" ON category_preferences;
CREATE POLICY "Users can manage own preferences" ON category_preferences
FOR ALL TO authenticated
USING ((SELECT auth.uid()) = user_id)
WITH CHECK ((SELECT auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can manage own metrics" ON metric_data_points;
CREATE POLICY "Users can manage own metrics" ON metric_data_points
FOR ALL TO authenticated
USING ((SELECT auth.uid()) = user_id)
WITH CHECK ((SELECT auth.uid()) = user_id);

-- Remove unused indexes
DROP INDEX IF EXISTS idx_categories_parent_id;
DROP INDEX IF EXISTS idx_categories_user_id;
DROP INDEX IF EXISTS idx_daily_metrics_category;
DROP INDEX IF EXISTS idx_daily_metrics_user_id;
DROP INDEX IF EXISTS idx_time_entries_category_id;
DROP INDEX IF EXISTS idx_time_entries_start_time;
DROP INDEX IF EXISTS idx_time_entries_user_id;
DROP INDEX IF EXISTS idx_category_definitions_user;
DROP INDEX IF EXISTS idx_category_definitions_parent;
DROP INDEX IF EXISTS idx_metric_data_points_category;
DROP INDEX IF EXISTS idx_metric_data_points_user_date;
DROP INDEX IF EXISTS idx_category_preferences_user;
DROP INDEX IF EXISTS idx_category_preferences_category;
DROP INDEX IF EXISTS idx_subcategories_category;

-- Add comments for documentation
COMMENT ON CONSTRAINT valid_color_format ON category_preferences IS 
'Ensures custom colors are in valid hex format (e.g., #FF0000)';