import { createClient } from 'npm:@supabase/supabase-js@2.39.7';

interface RequestPayload {
  entryId: number;
  operation: 'INSERT' | 'UPDATE' | 'DELETE';
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
  {
    auth: {
      persistSession: false,
    }
  }
);

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: corsHeaders,
    });
  }

  // Validate request method
  if (req.method !== 'POST') {
    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      {
        status: 405,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    );
  }

  try {
    // Parse and validate payload
    const payload = await req.json() as RequestPayload;
    
    if (!payload.entryId || !payload.operation) {
      return new Response(
        JSON.stringify({ error: 'Invalid payload: entryId and operation are required' }),
        {
          status: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders,
          },
        }
      );
    }

    if (!['INSERT', 'UPDATE', 'DELETE'].includes(payload.operation)) {
      return new Response(
        JSON.stringify({ error: 'Invalid operation: must be INSERT, UPDATE, or DELETE' }),
        {
          status: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders,
          },
        }
      );
    }

    // Call RPC function
    const { data, error } = await supabase
      .rpc('process_entry_changes', {
        p_entry_id: payload.entryId,
        p_operation: payload.operation,
      });

    if (error) throw error;

    // Return success response
    return new Response(
      JSON.stringify({ success: true, result: data }),
      {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    );

  } catch (error) {
    // Log error for debugging
    console.error('Error processing entry changes:', error);

    // Return error response
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error'
      }),
      {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    );
  }
});